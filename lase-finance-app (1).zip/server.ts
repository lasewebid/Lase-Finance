import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Support large payload for receipt images
app.use(express.json({ limit: '25mb' }));

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || ''
});

// API endpoint to analyze receipts using Gemini Vision
app.post('/api/scan-receipt', async (req, res) => {
  try {
    const { imageBase64, mimeType } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: 'Gambar struk (imageBase64) wajib dikirim.' });
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z]+;base64,/, '');
    const actualMimeType = mimeType || 'image/jpeg';

    const prompt = `Anda adalah asisten keuangan pribadi cerdas untuk aplikasi pengeluaran Indonesia.
Tolong ekstrak data dari gambar struk belanja / nota pembayaran / invoice ini secara akurat.
Kembalikan HANYA format JSON valid tanpa tanda kutip markdown (\`\`\`json) dengan struktur berikut:
{
  "merchant": "Nama Toko / Restoran / Merchant",
  "amount": 50000,
  "date": "YYYY-MM-DD",
  "category": "Makanan & Minuman" | "Belanja Harian" | "Transportasi" | "Tagihan & Utilitas" | "Hiburan" | "Kesehatan" | "Pendidikan" | "Lainnya",
  "paymentMethod": "QRIS" | "Tunai" | "Kartu Debit" | "Kartu Kredit" | "Transfer Bank" | "Lainnya",
  "notes": "Rincian singkat barang yang dibeli (misal: 2x Kopi, 1x Roti)",
  "items": [
    {"name": "Nama item", "qty": 1, "price": 25000}
  ],
  "confidenceScore": 0.95
}
Jika tanggal tidak tertera dengan jelas, gunakan tanggal hari ini. Jumlah (amount) harus berupa angka murni (number, IDR/rupiah).`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            { text: prompt },
            {
              inlineData: {
                data: cleanBase64,
                mimeType: actualMimeType,
              },
            },
          ],
        },
      ],
    });

    const responseText = response.text || '';
    let parsedData = {};
    try {
      const cleaned = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
      parsedData = JSON.parse(cleaned);
    } catch {
      parsedData = {
        merchant: "Struk Belanja",
        amount: 0,
        date: new Date().toISOString().split('T')[0],
        category: "Belanja Harian",
        paymentMethod: "QRIS",
        notes: responseText.slice(0, 100),
        items: []
      };
    }

    return res.json({ success: true, data: parsedData });
  } catch (error: any) {
    console.error('Error scanning receipt:', error);
    return res.status(500).json({
      error: error?.message || 'Gagal memproses struk dengan AI.',
    });
  }
});

// Helper function to recursively zip directory
async function addDirectoryToZip(zip: any, dirPath: string, rootDir: string) {
  const fs = await import('fs');
  const path = await import('path');
  const entries = await fs.promises.readdir(dirPath, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    const relativePath = path.relative(rootDir, fullPath);

    if (
      entry.name === 'node_modules' ||
      entry.name === 'dist' ||
      entry.name === '.git' ||
      entry.name === '.aistudio'
    ) {
      continue;
    }

    if (entry.isDirectory()) {
      await addDirectoryToZip(zip, fullPath, rootDir);
    } else {
      const content = await fs.promises.readFile(fullPath);
      zip.file(relativePath, content);
    }
  }
}

// API endpoint to download the entire application project as a ZIP file
app.get('/api/download-zip', async (_req, res) => {
  try {
    const JSZipModule: any = await import('jszip');
    const JSZip = JSZipModule.default || JSZipModule;
    const zip = new JSZip();

    await addDirectoryToZip(zip, __dirname, __dirname);

    const zipBuffer = await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 }
    });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="lase-finance-app.zip"');
    res.setHeader('Content-Length', zipBuffer.length.toString());
    res.send(zipBuffer);
  } catch (err: any) {
    console.error('Error creating zip:', err);
    res.status(500).json({ error: 'Gagal membuat file ZIP aplikasi: ' + err.message });
  }
});
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, port: PORT, host: '0.0.0.0' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Server running on port ${PORT}`);
  });
}

startServer();
