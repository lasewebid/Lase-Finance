export type TransactionType = 'income' | 'expense';

export interface Transaction {
  id: string;
  userId: string;
  title: string;
  amount: number;
  type: TransactionType;
  category: string;
  date: string; // YYYY-MM-DD
  notes?: string;
  paymentMethod?: string; // QRIS, Tunai, Transfer Bank, Kartu Debit, Kartu Kredit
  receiptUrl?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface CategoryItem {
  id: string;
  userId: string;
  name: string;
  type: TransactionType;
  icon: string;
  color: string;
  isDefault?: boolean;
}

export interface UserProfile {
  userId: string;
  name: string;
  email: string;
  photoUrl?: string;
  waNumber?: string;
  monthlyBudget: number;
  currency: string;
  waTemplate?: string;
  enableDailyReminder: boolean;
  reminderTime: string; // HH:mm
  biometricRegistered?: boolean;
  updatedAt?: string;
}

export interface JWTTokenData {
  token: string;
  expiresAt: number;
  payload: {
    sub: string;
    email: string;
    name: string;
    role: string;
    iat: number;
    exp: number;
    iss: string;
  };
}

export interface ReceiptScanResult {
  merchant: string;
  amount: number;
  date: string;
  category: string;
  paymentMethod: string;
  notes: string;
  items?: { name: string; qty: number; price: number }[];
  confidenceScore?: number;
}
