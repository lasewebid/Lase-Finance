import React, { useState } from 'react';
import { UserProfile, JWTTokenData } from '../types';
import { downloadAppZip } from '../lib/exportUtils';

interface NavbarProps {
  user: UserProfile | null;
  jwtData: JWTTokenData | null;
  isFirebaseConnected: boolean;
  onOpenAuth: () => void;
  onOpenProfile: () => void;
  onOpenNotifications: () => void;
  onLogout: () => void;
  onInstallPwa?: () => void;
  canInstallPwa?: boolean;
  onOpenPlayStore?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  jwtData,
  isFirebaseConnected,
  onOpenAuth,
  onOpenProfile,
  onOpenNotifications,
  onLogout,
  onInstallPwa,
  canInstallPwa,
  onOpenPlayStore
}) => {
  const [downloadingZip, setDownloadingZip] = useState(false);

  const handleDownloadZip = async () => {
    setDownloadingZip(true);
    await downloadAppZip();
    setTimeout(() => setDownloadingZip(false), 2000);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#090d16]/85 backdrop-blur-xl border-b border-white/10 px-4 py-3">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
        {/* Brand */}
        <div className="flex items-center space-x-3 cursor-pointer" onClick={onOpenProfile}>
          <div className="relative">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 p-0.5 shadow-lg shadow-cyan-500/20">
              {user?.photoUrl ? (
                <img
                  src={user.photoUrl}
                  alt={user.name}
                  className="w-full h-full rounded-[14px] object-cover"
                />
              ) : (
                <div className="w-full h-full bg-slate-900 rounded-[14px] flex items-center justify-center text-cyan-400 font-bold text-sm">
                  {user ? user.name.slice(0, 2).toUpperCase() : <i className="fa-solid fa-wallet"></i>}
                </div>
              )}
            </div>
            <span
              className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#090d16] ${
                isFirebaseConnected ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
              }`}
              title={isFirebaseConnected ? 'Tersinkronisasi Real-Time Firestore' : 'Penyimpanan Offline Aktif'}
            />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-extrabold text-white tracking-tight flex items-center gap-1.5">
                Lase Finance
                <span className="text-[10px] px-1.5 py-0.2 font-semibold bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 rounded-md">
                  v2.6 PRO
                </span>
              </h1>
            </div>
            <p className="text-[11px] text-slate-400 flex items-center gap-1">
              {user ? (
                <>
                  <span className="text-slate-200 font-medium">{user.name}</span>
                  <span className="text-slate-500">•</span>
                  <span className="text-cyan-400 flex items-center gap-1">
                    <i className="fa-solid fa-shield-halved text-[9px]"></i>
                    {jwtData ? 'JWT Aktif' : 'Sesi Aman'}
                  </span>
                </>
              ) : (
                'Manajemen Keuangan Cerdas'
              )}
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-2">
          {/* Play Store Deploy Button */}
          {onOpenPlayStore && (
            <button
              onClick={onOpenPlayStore}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 rounded-xl text-xs font-bold transition-all active:scale-95 shadow-sm shadow-emerald-500/10"
              title="Deploy & Rilis ke Google Play Store"
            >
              <i className="fa-brands fa-google-play text-xs text-emerald-400"></i>
              <span className="hidden sm:inline">Play Store Ready</span>
            </button>
          )}

          {/* Download App ZIP Button */}
          <button
            onClick={handleDownloadZip}
            disabled={downloadingZip}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-400 border border-cyan-500/30 rounded-xl text-xs font-bold transition-all active:scale-95 shadow-sm shadow-cyan-500/10 disabled:opacity-50"
            title="Unduh Seluruh Source Code & Proyek Aplikasi (.ZIP)"
          >
            <i className={`fa-solid ${downloadingZip ? 'fa-spinner fa-spin' : 'fa-file-zipper'} text-xs text-cyan-400`}></i>
            <span className="hidden sm:inline">{downloadingZip ? 'Menyiapkan...' : 'Unduh ZIP'}</span>
          </button>

          {/* PWA Install Button */}
          {canInstallPwa && (
            <button
              onClick={onInstallPwa}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 rounded-xl text-xs font-semibold transition-all active:scale-95"
              title="Pasang di Android / PC"
            >
              <i className="fa-solid fa-download text-xs"></i>
              <span>Pasang App</span>
            </button>
          )}

          {/* Daily Reminder Quick Button */}
          <button
            onClick={onOpenNotifications}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 border border-slate-700/60 transition-all active:scale-95 relative"
            title="Pengingat Harian & Notifikasi"
          >
            <i className="fa-solid fa-bell text-sm"></i>
            {user?.enableDailyReminder && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-cyan-400 rounded-full"></span>
            )}
          </button>

          {/* User Profile or Login */}
          {user ? (
            <div className="flex items-center space-x-2">
              <button
                onClick={onOpenProfile}
                className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-cyan-400 border border-cyan-500/30 transition-all active:scale-95"
                title="Setelan Profil"
              >
                <i className="fa-solid fa-user-gear text-sm"></i>
              </button>
              <button
                onClick={onLogout}
                className="p-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 transition-all active:scale-95"
                title="Keluar"
              >
                <i className="fa-solid fa-arrow-right-from-bracket text-sm"></i>
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-2 px-3.5 py-1.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-cyan-500/20 transition-all active:scale-95"
            >
              <i className="fa-solid fa-lock text-xs"></i>
              <span>Masuk / Akun</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
