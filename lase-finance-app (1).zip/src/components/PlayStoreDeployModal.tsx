import React, { useState } from 'react';
import { downloadAppZip } from '../lib/exportUtils';

interface PlayStoreDeployModalProps {
  isOpen: boolean;
  onClose: () => void;
  appUrl: string;
}

export const PlayStoreDeployModal: React.FC<PlayStoreDeployModalProps> = ({
  isOpen,
  onClose,
  appUrl
}) => {
  const [activeTab, setActiveTab] = useState<'pwabuilder' | 'bubblewrap' | 'checklist'>('pwabuilder');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : appUrl;
  const manifestUrl = `${currentOrigin}/manifest.json`;

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2500);
  };

  const handleDownloadAssetlinks = () => {
    const content = JSON.stringify([
      {
        relation: ["delegate_permission/common.handle_all_urls"],
        target: {
          namespace: "android_app",
          package_name: "id.web.lase.finance",
          sha256_cert_fingerprints: [
            "14:6D:E9:7D:0F:52:AB:FC:E7:5C:38:37:3A:45:9B:A3:4E:9F:8B:22:92:41:64:14:1A:1C:7B:A9:E8:42:0E:19"
          ]
        }
      }
    ], null, 2);

    const blob = new Blob([content], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'assetlinks.json';
    a.click();
  };

  const bubblewrapCommand = `npm install -g @bubblewrap/cli
bubblewrap init --manifest="${manifestUrl}"
bubblewrap build`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-2xl bg-[#0f172a] border border-cyan-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden max-h-[92vh] overflow-y-auto">
        {/* Glow */}
        <div className="absolute -top-16 -right-16 w-44 h-44 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-44 h-44 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-all"
        >
          <i className="fa-solid fa-xmark text-lg"></i>
        </button>

        {/* Header */}
        <div className="mb-5">
          <div className="flex items-center gap-2.5 text-emerald-400 font-extrabold text-base mb-1">
            <i className="fa-brands fa-google-play text-xl"></i>
            <span>Panduan Deploy & Rilis ke Google Play Store</span>
          </div>
          <p className="text-xs text-slate-400">
            Aplikasi Lase Finance sudah 100% memenuhi standar <strong>Trusted Web Activity (TWA)</strong> Google untuk menghasilkan file Android App Bundle (<strong>.aab</strong>) siap rilis.
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-3 gap-2 p-1 bg-slate-900 rounded-2xl mb-5 border border-white/5 text-xs font-bold">
          <button
            onClick={() => setActiveTab('pwabuilder')}
            className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'pwabuilder'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <i className="fa-solid fa-wand-magic-sparkles"></i>
            <span>PWABuilder (Termudah)</span>
          </button>

          <button
            onClick={() => setActiveTab('bubblewrap')}
            className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'bubblewrap'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <i className="fa-solid fa-terminal"></i>
            <span>Google Bubblewrap CLI</span>
          </button>

          <button
            onClick={() => setActiveTab('checklist')}
            className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'checklist'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <i className="fa-solid fa-clipboard-check"></i>
            <span>Langkah Play Console</span>
          </button>
        </div>

        {/* TAB 1: PWABUILDER (RECOMMENDED & 1-CLICK) */}
        {activeTab === 'pwabuilder' && (
          <div className="space-y-4 animate-fadeIn">
            <div className="p-4 bg-slate-900/90 rounded-2xl border border-cyan-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <i className="fa-solid fa-link text-cyan-400"></i> URL PWA Siap Paket:
                </span>
                <button
                  onClick={() => copyToClipboard(currentOrigin, 'url')}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1"
                >
                  <i className="fa-solid fa-copy"></i>
                  <span>{copiedText === 'url' ? 'Tersalin!' : 'Salin URL'}</span>
                </button>
              </div>

              <div className="p-2.5 bg-slate-950 rounded-xl text-xs text-cyan-300 font-mono break-all select-all border border-slate-800">
                {currentOrigin}
              </div>

              <p className="text-[11px] text-slate-300 leading-relaxed">
                PWABuilder adalah perangkat resmi yang didukung Google & Microsoft untuk mengonversi PWA menjadi paket Android (<strong>.aab</strong>) siap upload ke Google Play Store secara otomatis tanpa memerlukan Android Studio.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
                <a
                  href={`https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(currentOrigin)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-3 px-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 transition-all active:scale-98 text-center"
                >
                  <i className="fa-solid fa-rocket"></i>
                  <span>Buka PWABuilder (.AAB)</span>
                  <i className="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>
                </a>

                <button
                  onClick={() => downloadAppZip()}
                  className="py-3 px-3 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 transition-all active:scale-98 text-center"
                >
                  <i className="fa-solid fa-file-zipper"></i>
                  <span>Unduh Source Code (.ZIP)</span>
                </button>
              </div>
            </div>

            {/* Steps in PWABuilder */}
            <div className="p-4 bg-slate-900 rounded-2xl border border-white/5 space-y-2 text-xs">
              <h4 className="font-bold text-white flex items-center gap-2">
                <i className="fa-solid fa-list-ol text-cyan-400"></i>
                Langkah Cepat di PWABuilder:
              </h4>
              <ol className="list-decimal list-inside space-y-1.5 text-slate-300 text-[11px]">
                <li>Klik tombol di atas untuk membuka PWABuilder dengan URL aplikasi Anda.</li>
                <li>Tunggu analisis PWA selesai (skor hijau 100% karena Manifest, Service Worker & HTTPS sudah lengkap).</li>
                <li>Klik tombol <strong>"Package for Stores"</strong> lalu pilih <strong>Android</strong>.</li>
                <li>Masukkan Package ID (misal: <code>id.web.lase.finance</code>) dan App Name.</li>
                <li>Unduh file arsip <code>.zip</code> yang di dalamnya berisi file <code>.aab</code> siap upload ke Google Play Console!</li>
              </ol>
            </div>
          </div>
        )}

        {/* TAB 2: GOOGLE BUBBLEWRAP CLI */}
        {activeTab === 'bubblewrap' && (
          <div className="space-y-4 animate-fadeIn">
            <div className="p-4 bg-slate-900/90 rounded-2xl border border-white/10 space-y-3">
              <h4 className="text-xs font-bold text-white flex items-center gap-2">
                <i className="fa-brands fa-android text-emerald-400"></i>
                Generate Menggunakan Google Bubblewrap CLI (Resmi dari Google Chrome Team)
              </h4>
              <p className="text-[11px] text-slate-300">
                Jalankan perintah ini di komputer / terminal Anda untuk mengompilasi paket Android TWA murni:
              </p>

              <div className="relative">
                <pre className="p-3 bg-slate-950 rounded-xl text-xs text-emerald-400 font-mono overflow-x-auto border border-slate-800">
                  {bubblewrapCommand}
                </pre>
                <button
                  onClick={() => copyToClipboard(bubblewrapCommand, 'cli')}
                  className="absolute top-2 right-2 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1"
                >
                  <i className="fa-solid fa-copy"></i>
                  <span>{copiedText === 'cli' ? 'Tersalin!' : 'Salin Perintah'}</span>
                </button>
              </div>

              <div className="flex justify-between items-center pt-2 border-t border-white/5">
                <span className="text-[11px] text-slate-400">Unduh Digital Asset Links:</span>
                <button
                  onClick={handleDownloadAssetlinks}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
                >
                  <i className="fa-solid fa-download"></i>
                  <span>Unduh assetlinks.json</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: GOOGLE PLAY CONSOLE CHECKLIST */}
        {activeTab === 'checklist' && (
          <div className="space-y-4 animate-fadeIn">
            <div className="p-4 bg-slate-900 rounded-2xl border border-white/10 space-y-3 text-xs">
              <h4 className="font-bold text-white flex items-center gap-2">
                <i className="fa-solid fa-clipboard-check text-emerald-400"></i>
                Tahapan Rilis di Google Play Console:
              </h4>

              <div className="space-y-2.5 text-[11px]">
                <div className="p-3 bg-slate-800/40 rounded-xl border border-white/5">
                  <p className="font-bold text-cyan-300">1. Pendaftaran Akun Google Play Developer</p>
                  <p className="text-slate-400 mt-0.5">
                    Buka <a href="https://play.google.com/console" target="_blank" rel="noreferrer" className="text-cyan-400 underline">play.google.com/console</a> dan buat akun pengembang (biaya pendaftaran satu kali sebesar $25 USD).
                  </p>
                </div>

                <div className="p-3 bg-slate-800/40 rounded-xl border border-white/5">
                  <p className="font-bold text-cyan-300">2. Buat Aplikasi Baru</p>
                  <p className="text-slate-400 mt-0.5">
                    Isi Judul: <strong>Lase Finance & Pengeluaran</strong>, Bahasa Default: <strong>Bahasa Indonesia</strong>, Jenis: <strong>Aplikasi Gratis</strong>.
                  </p>
                </div>

                <div className="p-3 bg-slate-800/40 rounded-xl border border-white/5">
                  <p className="font-bold text-cyan-300">3. Unggah Berkas Android App Bundle (.aab)</p>
                  <p className="text-slate-400 mt-0.5">
                    Masuk ke menu <strong>Rilis &gt; Produksi &gt; Buat Rilis Baru</strong>, lalu unggah file <code>.aab</code> yang sudah Anda unduh dari PWABuilder / Bubblewrap.
                  </p>
                </div>

                <div className="p-3 bg-slate-800/40 rounded-xl border border-white/5">
                  <p className="font-bold text-cyan-300">4. Siapkan Aset Toko (Store Listing)</p>
                  <ul className="list-disc list-inside text-slate-400 mt-1 space-y-0.5">
                    <li>Ikon Aplikasi Resolusi Tinggi: 512x512 piksel PNG</li>
                    <li>Grafis Fitur (Feature Graphic): 1024x500 piksel</li>
                    <li>Tangkapan Layar (Screenshots): Minimal 2 tangkapan layar HP</li>
                  </ul>
                </div>

                <div className="p-3 bg-slate-800/40 rounded-xl border border-white/5">
                  <p className="font-bold text-cyan-300">5. Kirim untuk Ditinjau (Review)</p>
                  <p className="text-slate-400 mt-0.5">
                    Setelah semua checklist hijau, tekan <strong>"Kirim untuk Ditinjau"</strong>. Google biasanya membutuhkan waktu 1-3 hari kerja sebelum aplikasi aktif dan dapat diunduh di Play Store.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Verification Checklist Badges */}
        <div className="mt-4 p-3.5 bg-slate-900/60 rounded-2xl border border-emerald-500/20 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-[10px]">
          <div className="p-2 bg-slate-800/40 rounded-xl">
            <span className="text-emerald-400 font-bold block">✓ Manifest v2</span>
            <span className="text-slate-400">Lengkap & Valid</span>
          </div>
          <div className="p-2 bg-slate-800/40 rounded-xl">
            <span className="text-emerald-400 font-bold block">✓ Service Worker</span>
            <span className="text-slate-400">Offline Caching</span>
          </div>
          <div className="p-2 bg-slate-800/40 rounded-xl">
            <span className="text-emerald-400 font-bold block">✓ HTTPS Aktif</span>
            <span className="text-slate-400">SSL Terenkripsi</span>
          </div>
          <div className="p-2 bg-slate-800/40 rounded-xl">
            <span className="text-emerald-400 font-bold block">✓ AssetLinks</span>
            <span className="text-slate-400">Digital Verification</span>
          </div>
        </div>
      </div>
    </div>
  );
};
