import React, { useState } from 'react';
import { Transaction, TransactionType, CategoryItem, UserProfile } from '../types';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (tx: Omit<Transaction, 'id' | 'userId'>, sendWhatsApp: boolean) => void;
  categories: CategoryItem[];
  userProfile?: UserProfile | null;
  initialData?: Partial<Transaction>;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  categories,
  userProfile,
  initialData
}) => {
  const [type, setType] = useState<TransactionType>(initialData?.type || 'expense');
  const [title, setTitle] = useState(initialData?.title || '');
  const [amount, setAmount] = useState<string>(initialData?.amount ? String(initialData.amount) : '');
  const [category, setCategory] = useState(initialData?.category || '');
  const [date, setDate] = useState(initialData?.date || new Date().toISOString().split('T')[0]);
  const [paymentMethod, setPaymentMethod] = useState(initialData?.paymentMethod || 'QRIS');
  const [notes, setNotes] = useState(initialData?.notes || '');
  const [sendWhatsApp, setSendWhatsApp] = useState(false);

  if (!isOpen) return null;

  // Filter categories by type
  const availableCategories = categories.filter(c => c.type === type);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (!title.trim() || isNaN(parsedAmount) || parsedAmount <= 0) {
      alert('Mohon isi nama transaksi dan nominal yang valid!');
      return;
    }

    const selectedCategory = category || (availableCategories[0]?.name || 'Lainnya');

    onSave({
      title: title.trim(),
      amount: parsedAmount,
      type,
      category: selectedCategory,
      date,
      paymentMethod,
      notes: notes.trim(),
      createdAt: new Date().toISOString()
    }, sendWhatsApp);

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-md bg-[#0f172a] border border-cyan-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        {/* Glow */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-all"
        >
          <i className="fa-solid fa-xmark text-lg"></i>
        </button>

        {/* Modal Title */}
        <div className="mb-5">
          <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
            <i className={`fa-solid ${type === 'income' ? 'fa-circle-plus text-emerald-400' : 'fa-circle-minus text-rose-400'}`}></i>
            <span>{type === 'income' ? 'Catat Pemasukan Baru' : 'Catat Pengeluaran Baru'}</span>
          </h3>
          <p className="text-xs text-slate-400">Sinkronisasi otomatis dengan database real-time</p>
        </div>

        {/* Type Switcher */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-900 rounded-2xl mb-4 border border-white/5">
          <button
            type="button"
            onClick={() => {
              setType('expense');
              setCategory('');
            }}
            className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              type === 'expense'
                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <i className="fa-solid fa-arrow-trend-down"></i>
            <span>Pengeluaran</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setType('income');
              setCategory('');
            }}
            className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              type === 'income'
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <i className="fa-solid fa-arrow-trend-up"></i>
            <span>Pemasukan</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {/* Title */}
          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1">
              {type === 'income' ? 'Sumber Pemasukan / Keterangan' : 'Nama Kebutuhan / Toko'}
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={type === 'income' ? 'Contoh: Gaji Bulanan, Proyek Desain' : 'Contoh: Makan Siang, Belanja Supermarket'}
              className="w-full bg-slate-800/80 border border-slate-700 rounded-xl py-2.5 px-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
            />
          </div>

          {/* Amount & Date in 2 columns */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Nominal (Rp)</label>
              <input
                type="number"
                required
                min="1"
                step="any"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0"
                className="w-full bg-slate-800/80 border border-slate-700 rounded-xl py-2.5 px-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono"
              />
            </div>
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Tanggal</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-800/80 border border-slate-700 rounded-xl py-2.5 px-3 text-xs text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          {/* Category & Payment Method */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Kategori</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-slate-800/80 border border-slate-700 rounded-xl py-2.5 px-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
              >
                {availableCategories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Metode Pembayaran</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full bg-slate-800/80 border border-slate-700 rounded-xl py-2.5 px-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
              >
                <option value="QRIS">QRIS</option>
                <option value="Tunai">Tunai (Cash)</option>
                <option value="Transfer Bank">Transfer Bank</option>
                <option value="Kartu Debit">Kartu Debit</option>
                <option value="Kartu Kredit">Kartu Kredit</option>
                <option value="E-Wallet">E-Wallet (GoPay/OVO/Shopee)</option>
              </select>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1">Catatan Tambahan (Opsional)</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Contoh: Beli dengan promo diskon 20%"
              className="w-full bg-slate-800/80 border border-slate-700 rounded-xl py-2 px-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
            />
          </div>

          {/* Automatic WhatsApp Share Option */}
          <div className="p-3 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <i className="fa-brands fa-whatsapp text-emerald-400 text-lg"></i>
              <div>
                <p className="text-xs font-bold text-white">Kirim Notifikasi ke WhatsApp</p>
                <p className="text-[10px] text-slate-400">Otomatis kirim rekap ke nomor terdaftar</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={sendWhatsApp}
              onChange={(e) => setSendWhatsApp(e.target.checked)}
              className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className={`w-full py-3 font-bold text-xs rounded-xl shadow-lg active:scale-98 transition-all flex items-center justify-center gap-2 text-white ${
              type === 'income'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 shadow-emerald-500/25'
                : 'bg-gradient-to-r from-rose-500 to-red-600 hover:from-rose-400 hover:to-red-500 shadow-rose-500/25'
            }`}
          >
            <i className="fa-solid fa-check"></i>
            <span>Simpan Transaksi</span>
          </button>
        </form>
      </div>
    </div>
  );
};
