import React, { useState } from 'react';
import { Transaction, UserProfile } from '../types';
import { formatRupiah } from '../lib/exportUtils';

interface WhatsAppSenderProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile?: UserProfile | null;
  transaction?: Transaction | null;
  dailyTransactions?: Transaction[];
  onSaveTemplate?: (template: string, phone: string) => void;
}

export const WhatsAppSender: React.FC<WhatsAppSenderProps> = ({
  isOpen,
  onClose,
  userProfile,
  transaction,
  dailyTransactions = [],
  onSaveTemplate
}) => {
  const [phoneNumber, setPhoneNumber] = useState<string>(userProfile?.waNumber || '');
  const [mode, setMode] = useState<'single' | 'daily'>(transaction ? 'single' : 'daily');
  const [customTemplate, setCustomTemplate] = useState<string>(
    userProfile?.waTemplate ||
      `*🧾 NOTIFIKASI TRANSAKSI - LASE FINANCE*\n` +
      `Halo {nama}, transaksi baru telah berhasil dicatat:\n` +
      `-------------------------------------------\n` +
      `📌 *Tipe:* {tipe}\n` +
      `🏷️ *Keterangan:* {keterangan}\n` +
      `💰 *Jumlah:* {jumlah}\n` +
      `📂 *Kategori:* {kategori}\n` +
      `💳 *Metode:* {metode}\n` +
      `📅 *Tanggal:* {tanggal}\n` +
      `📝 *Catatan:* {catatan}\n` +
      `-------------------------------------------\n` +
      `_Tercatat aman & tersinkronisasi via Lase Finance Web_`
  );

  if (!isOpen) return null;

  // Build the message for single transaction
  const generateSingleMessage = (): string => {
    if (!transaction) return '';
    return customTemplate
      .replace(/{nama}/g, userProfile?.name || 'Pengguna')
      .replace(/{tipe}/g, transaction.type === 'income' ? 'Pemasukan (+)' : 'Pengeluaran (-)')
      .replace(/{keterangan}/g, transaction.title)
      .replace(/{jumlah}/g, formatRupiah(transaction.amount))
      .replace(/{kategori}/g, transaction.category)
      .replace(/{metode}/g, transaction.paymentMethod || 'Tunai')
      .replace(/{tanggal}/g, transaction.date)
      .replace(/{catatan}/g, transaction.notes || '-');
  };

  // Build the message for daily summary
  const generateDailyMessage = (): string => {
    const todayStr = new Date().toISOString().split('T')[0];
    const items = dailyTransactions.filter(t => t.date === todayStr);

    const totalIncome = items.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
    const totalExpense = items.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
    const net = totalIncome - totalExpense;

    let msg = `*📊 REKAP KEUANGAN HARIAN - LASE FINANCE*\n`;
    msg += `Pengguna: *${userProfile?.name || 'Pengguna'}*\n`;
    msg += `Tanggal: *${todayStr}*\n`;
    msg += `-------------------------------------------\n`;

    if (items.length === 0) {
      msg += `Belum ada transaksi yang dicatat untuk hari ini.\n`;
    } else {
      items.forEach((it, idx) => {
        const sign = it.type === 'income' ? '+' : '-';
        msg += `${idx + 1}. *${it.title}* (${it.category})\n   👉 ${sign}${formatRupiah(it.amount)} [${it.paymentMethod || 'Tunai'}]\n`;
      });
    }

    msg += `-------------------------------------------\n`;
    msg += `📈 *Total Pemasukan:* ${formatRupiah(totalIncome)}\n`;
    msg += `📉 *Total Pengeluaran:* ${formatRupiah(totalExpense)}\n`;
    msg += `💵 *Saldo Bersih Hari Ini:* ${formatRupiah(net)}\n\n`;
    msg += `_Laporan otomatis dari Lase Finance & Pengeluaran Web ID_`;
    return msg;
  };

  const previewText = mode === 'single' ? generateSingleMessage() : generateDailyMessage();

  const handleSendWhatsApp = () => {
    let raw = phoneNumber.trim();
    if (!raw) {
      alert('Masukkan nomor WhatsApp tujuan terlebih dahulu.');
      return;
    }

    // Format phone to 628xxx
    if (raw.startsWith('0')) {
      raw = '62' + raw.substring(1);
    } else if (raw.startsWith('+')) {
      raw = raw.substring(1);
    }

    if (onSaveTemplate) {
      onSaveTemplate(customTemplate, phoneNumber);
    }

    const encoded = encodeURIComponent(previewText);
    const url = `https://wa.me/${raw}?text=${encoded}`;
    window.open(url, '_blank');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-lg bg-[#0f172a] border border-emerald-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden max-h-[92vh] overflow-y-auto">
        {/* Glow */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-all"
        >
          <i className="fa-solid fa-xmark text-lg"></i>
        </button>

        {/* Header */}
        <div className="mb-4">
          <div className="flex items-center gap-2 text-emerald-400 font-extrabold text-sm mb-1">
            <i className="fa-brands fa-whatsapp text-xl"></i>
            <span>Pusat Notifikasi & Rekap WhatsApp</span>
          </div>
          <p className="text-xs text-slate-400">
            Kirim ringkasan otomatis dengan format pesan rapi dan kustom ke nomor WhatsApp Anda.
          </p>
        </div>

        {/* Mode Selector */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-900 rounded-2xl mb-4 border border-white/5">
          <button
            type="button"
            onClick={() => setMode('daily')}
            className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              mode === 'daily'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <i className="fa-solid fa-calendar-day"></i>
            <span>Rekap Hari Ini</span>
          </button>
          <button
            type="button"
            disabled={!transaction}
            onClick={() => setMode('single')}
            className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              mode === 'single'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-md'
                : 'text-slate-400 hover:text-white'
            } disabled:opacity-40`}
          >
            <i className="fa-solid fa-receipt"></i>
            <span>Transaksi Terakhir</span>
          </button>
        </div>

        {/* Phone Input */}
        <div className="space-y-3 mb-4">
          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1">
              Nomor WhatsApp Tujuan (HP)
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-xs text-slate-400 font-semibold">+62</span>
              <input
                type="tel"
                value={phoneNumber.startsWith('62') ? phoneNumber.substring(2) : phoneNumber.startsWith('0') ? phoneNumber.substring(1) : phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="812-3456-7890"
                className="w-full bg-slate-800/80 border border-slate-700 rounded-xl py-2 pl-12 pr-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400 font-mono"
              />
            </div>
            <p className="text-[10px] text-slate-400 mt-1">
              Nomor ini akan disimpan di profil Anda untuk kemudahan pengiriman selanjutnya.
            </p>
          </div>

          {/* Template Editor (for single transaction mode) */}
          {mode === 'single' && (
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-[11px] font-semibold text-slate-300">
                  Kustomisasi Template Pesan
                </label>
                <span className="text-[10px] text-cyan-400">Tag: {'{nama}'}, {'{jumlah}'}, {'{kategori}'}</span>
              </div>
              <textarea
                rows={4}
                value={customTemplate}
                onChange={(e) => setCustomTemplate(e.target.value)}
                className="w-full bg-slate-800/80 border border-slate-700 rounded-xl p-2.5 text-[11px] text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400 font-mono resize-none"
              />
            </div>
          )}

          {/* Live Preview Box */}
          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1">
              Pratinjau Pesan WhatsApp
            </label>
            <div className="p-3 bg-slate-900 border border-emerald-500/20 rounded-2xl max-h-48 overflow-y-auto">
              <pre className="text-[11px] text-emerald-300 font-sans whitespace-pre-wrap leading-relaxed">
                {previewText}
              </pre>
            </div>
          </div>
        </div>

        {/* Send Button */}
        <button
          type="button"
          onClick={handleSendWhatsApp}
          className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 active:scale-98 transition-all"
        >
          <i className="fa-brands fa-whatsapp text-base"></i>
          <span>Kirim Sekarang ke WhatsApp</span>
        </button>
      </div>
    </div>
  );
};
