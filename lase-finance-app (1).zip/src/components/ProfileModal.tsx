import React, { useState, useRef } from 'react';
import { UserProfile } from '../types';
import { registerBiometric, isBiometricRegistered, disableBiometric } from '../lib/biometrics';
import { requestNotificationPermission, sendPushNotification } from '../lib/notifications';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onSaveProfile: (updated: UserProfile) => void;
  onExportBackup: () => void;
  onImportBackup: (file: File) => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  user,
  onSaveProfile,
  onExportBackup,
  onImportBackup
}) => {
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [photoUrl, setPhotoUrl] = useState(user.photoUrl || '');
  const [waNumber, setWaNumber] = useState(user.waNumber || '');
  const [monthlyBudget, setMonthlyBudget] = useState(String(user.monthlyBudget || 5000000));
  const [enableDailyReminder, setEnableDailyReminder] = useState(user.enableDailyReminder);
  const [reminderTime, setReminderTime] = useState(user.reminderTime || '20:00');
  const [waTemplate, setWaTemplate] = useState(user.waTemplate || '');
  const [biometricEnabled, setBiometricEnabled] = useState(isBiometricRegistered());
  const [statusMessage, setStatusMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const backupInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      setPhotoUrl(evt.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleToggleBiometric = async () => {
    if (biometricEnabled) {
      disableBiometric();
      setBiometricEnabled(false);
      setStatusMessage('Biometrik dinonaktifkan.');
    } else {
      const ok = await registerBiometric(user.userId, user.email);
      if (ok) {
        setBiometricEnabled(true);
        setStatusMessage('Biometrik perangkat berhasil didaftarkan!');
      } else {
        setStatusMessage('Gagal mengaktifkan biometrik.');
      }
    }
  };

  const handleTestNotification = async () => {
    const perm = await requestNotificationPermission();
    if (perm === 'granted') {
      sendPushNotification('Lase Finance Pengingat 🔔', {
        body: 'Notifikasi berhasil diaktifkan! Anda akan menerima pengingat harian untuk mencatat keuangan.',
        tag: 'test'
      });
      setStatusMessage('Notifikasi uji coba dikirim!');
    } else {
      setStatusMessage('Izin notifikasi ditolak oleh browser.');
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserProfile = {
      ...user,
      name: name.trim() || user.name,
      email: email.trim() || user.email,
      photoUrl,
      waNumber: waNumber.trim(),
      monthlyBudget: parseFloat(monthlyBudget) || 5000000,
      enableDailyReminder,
      reminderTime,
      waTemplate: waTemplate.trim() || undefined,
      biometricRegistered: biometricEnabled
    };

    onSaveProfile(updated);
    setStatusMessage('Profil berhasil disimpan!');
    setTimeout(() => {
      onClose();
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-lg bg-[#0f172a] border border-cyan-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden max-h-[92vh] overflow-y-auto">
        {/* Glow */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-all"
        >
          <i className="fa-solid fa-xmark text-lg"></i>
        </button>

        {/* Header */}
        <div className="mb-5">
          <div className="flex items-center gap-2 text-cyan-400 font-extrabold text-sm mb-1">
            <i className="fa-solid fa-user-shield text-base"></i>
            <span>Setelan Profil & Keamanan Pengguna</span>
          </div>
          <p className="text-xs text-slate-400">
            Kelola identitas, anggaran bulanan, WhatsApp, biometrik, dan notifikasi pengingat.
          </p>
        </div>

        {statusMessage && (
          <div className="p-3 mb-4 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-xs flex items-center gap-2 animate-fadeIn">
            <i className="fa-solid fa-circle-check"></i>
            <span>{statusMessage}</span>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-4">
          {/* Avatar Upload */}
          <div className="flex items-center space-x-4 p-3 bg-slate-900 rounded-2xl border border-white/5">
            <div className="relative">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 p-0.5 shadow-md overflow-hidden">
                {photoUrl ? (
                  <img src={photoUrl} alt="Avatar" className="w-full h-full object-cover rounded-[14px]" />
                ) : (
                  <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-cyan-400 text-xl font-bold">
                    {name.slice(0, 2).toUpperCase()}
                  </div>
                )}
              </div>
            </div>

            <div className="flex-1">
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handleAvatarUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 transition-all active:scale-95 flex items-center gap-2"
              >
                <i className="fa-solid fa-camera text-cyan-400"></i>
                <span>Ganti Foto / Logo</span>
              </button>
              <p className="text-[10px] text-slate-400 mt-1">Mendukung format gambar PNG, JPG, atau WEBP.</p>
            </div>
          </div>

          {/* Name & Email */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Nama Lengkap</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Alamat Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          {/* Monthly Budget & WA Number */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Batas Anggaran Bulanan (Rp)</label>
              <input
                type="number"
                value={monthlyBudget}
                onChange={(e) => setMonthlyBudget(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
              />
            </div>
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Nomor WhatsApp Rekap</label>
              <input
                type="tel"
                value={waNumber}
                onChange={(e) => setWaNumber(e.target.value)}
                placeholder="081234567890"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
              />
            </div>
          </div>

          {/* Biometric Security Card */}
          <div className="p-3.5 bg-slate-900 rounded-2xl border border-white/5 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
                  <i className="fa-solid fa-fingerprint text-base"></i>
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Keamanan Biometrik</h4>
                  <p className="text-[10px] text-slate-400">Masuk via Sidik Jari / Pemindai Wajah</p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleToggleBiometric}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all active:scale-95 ${
                  biometricEnabled
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                }`}
              >
                {biometricEnabled ? 'Nonaktifkan' : 'Aktifkan'}
              </button>
            </div>
          </div>

          {/* Daily Reminder & Push Notifications */}
          <div className="p-3.5 bg-slate-900 rounded-2xl border border-white/5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
                  <i className="fa-solid fa-bell text-base"></i>
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Pengingat Harian Otomatis</h4>
                  <p className="text-[10px] text-slate-400">Notifikasi disiplin mencatat transaksi</p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={enableDailyReminder}
                onChange={(e) => setEnableDailyReminder(e.target.checked)}
                className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
              />
            </div>

            {enableDailyReminder && (
              <div className="flex items-center justify-between pt-2 border-t border-white/5">
                <span className="text-[11px] text-slate-300">Jam Pengingat Harian:</span>
                <div className="flex items-center gap-2">
                  <input
                    type="time"
                    value={reminderTime}
                    onChange={(e) => setReminderTime(e.target.value)}
                    className="bg-slate-800 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white"
                  />
                  <button
                    type="button"
                    onClick={handleTestNotification}
                    className="px-2 py-1 text-[10px] bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded-lg border border-slate-700 transition-all"
                  >
                    Uji Coba
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Backup & Restore Data */}
          <div className="p-3.5 bg-slate-900 rounded-2xl border border-white/5 space-y-2">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                <i className="fa-solid fa-cloud-arrow-down text-base"></i>
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Cadangkan & Pemulihan (Backup JSON)</h4>
                <p className="text-[10px] text-slate-400">Simpan salinan data offline untuk keamanan ganda</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={onExportBackup}
                className="py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5"
              >
                <i className="fa-solid fa-download"></i>
                <span>Ekspor JSON</span>
              </button>
              <button
                type="button"
                onClick={() => backupInputRef.current?.click()}
                className="py-2 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5"
              >
                <i className="fa-solid fa-upload"></i>
                <span>Impor JSON</span>
              </button>
              <input
                type="file"
                ref={backupInputRef}
                accept=".json"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onImportBackup(f);
                }}
                className="hidden"
              />
            </div>
          </div>

          {/* Submit */}
          <button
            type="submit"
            className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-cyan-500/25 active:scale-98 transition-all"
          >
            Simpan Perubahan Profil
          </button>
        </form>
      </div>
    </div>
  );
};
