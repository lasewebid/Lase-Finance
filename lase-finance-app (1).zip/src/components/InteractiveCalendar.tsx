import React, { useState, useMemo } from 'react';
import { Transaction } from '../types';
import { formatRupiah } from '../lib/exportUtils';

interface InteractiveCalendarProps {
  transactions: Transaction[];
  onSelectTransaction?: (tx: Transaction) => void;
  onDeleteTransaction?: (id: string) => void;
}

export const InteractiveCalendar: React.FC<InteractiveCalendarProps> = ({
  transactions,
  onSelectTransaction,
  onDeleteTransaction
}) => {
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [selectedDateStr, setSelectedDateStr] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth(); // 0-indexed

  // Month navigation
  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const goToToday = () => {
    const today = new Date();
    setCurrentDate(today);
    setSelectedDateStr(today.toISOString().split('T')[0]);
  };

  // Month name in Indonesian
  const monthNames = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];

  const daysOfWeek = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];

  // Days in current month
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayIndex = new Date(year, month, 1).getDay(); // 0 = Sun

  // Aggregate transactions by date
  const transactionsByDate = useMemo(() => {
    const map: { [dateStr: string]: { income: number; expense: number; items: Transaction[] } } = {};
    transactions.forEach(t => {
      if (!map[t.date]) {
        map[t.date] = { income: 0, expense: 0, items: [] };
      }
      map[t.date].items.push(t);
      if (t.type === 'income') map[t.date].income += t.amount;
      else map[t.date].expense += t.amount;
    });
    return map;
  }, [transactions]);

  // Selected date's transactions
  const selectedDayData = transactionsByDate[selectedDateStr] || { income: 0, expense: 0, items: [] };

  return (
    <div className="space-y-4">
      {/* Calendar Container */}
      <div className="p-5 rounded-3xl bg-slate-900/80 border border-white/10 shadow-xl space-y-4">
        {/* Header with Month / Year & Controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="text-base font-extrabold text-white flex items-center gap-2">
              <i className="fa-solid fa-calendar-days text-cyan-400"></i>
              <span>{monthNames[month]} {year}</span>
            </h3>
            <button
              onClick={goToToday}
              className="px-2.5 py-1 text-[10px] font-bold bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 rounded-lg hover:bg-cyan-500/25 transition-all"
            >
              Hari Ini
            </button>
          </div>

          <div className="flex items-center space-x-1">
            <button
              onClick={prevMonth}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all active:scale-95"
              title="Bulan Sebelumnya"
            >
              <i className="fa-solid fa-chevron-left text-xs"></i>
            </button>
            <button
              onClick={nextMonth}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all active:scale-95"
              title="Bulan Berikutnya"
            >
              <i className="fa-solid fa-chevron-right text-xs"></i>
            </button>
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-4 text-[11px] text-slate-400 border-b border-white/5 pb-2">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span> Pemasukan
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-rose-400"></span> Pengeluaran
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full border border-cyan-400"></span> Tanggal Dipilih
          </span>
        </div>

        {/* Days of week header */}
        <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-bold text-slate-400">
          {daysOfWeek.map((day, idx) => (
            <div key={day} className={idx === 0 ? 'text-rose-400' : ''}>
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-1">
          {/* Empty cells before 1st day */}
          {Array.from({ length: firstDayIndex }).map((_, i) => (
            <div key={`empty-${i}`} className="h-16 rounded-2xl bg-slate-950/20 opacity-30" />
          ))}

          {/* Actual Month Days */}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const dayNum = i + 1;
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
            const isToday = dateStr === new Date().toISOString().split('T')[0];
            const isSelected = dateStr === selectedDateStr;
            const dayData = transactionsByDate[dateStr];

            return (
              <div
                key={dateStr}
                onClick={() => setSelectedDateStr(dateStr)}
                className={`h-16 p-1.5 rounded-2xl flex flex-col justify-between text-left transition-all cursor-pointer relative overflow-hidden ${
                  isSelected
                    ? 'bg-cyan-500/20 border-2 border-cyan-400 shadow-lg shadow-cyan-500/20'
                    : isToday
                    ? 'bg-slate-800/90 border border-cyan-500/40'
                    : 'bg-slate-800/40 hover:bg-slate-800/80 border border-white/5'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span
                    className={`text-xs font-bold leading-none ${
                      isSelected
                        ? 'text-cyan-300'
                        : isToday
                        ? 'text-cyan-400 font-extrabold'
                        : 'text-slate-300'
                    }`}
                  >
                    {dayNum}
                  </span>
                  {dayData && dayData.items.length > 0 && (
                    <span className="text-[9px] px-1 bg-slate-900/80 rounded-md text-slate-400 font-mono">
                      {dayData.items.length}
                    </span>
                  )}
                </div>

                {/* Badges for cashflow */}
                {dayData && (
                  <div className="space-y-0.5">
                    {dayData.income > 0 && (
                      <div className="text-[9px] font-bold text-emerald-400 bg-emerald-500/15 px-1 rounded truncate leading-tight">
                        +{dayData.income >= 1000000 ? `${(dayData.income / 1000000).toFixed(1)}M` : `${Math.round(dayData.income / 1000)}k`}
                      </div>
                    )}
                    {dayData.expense > 0 && (
                      <div className="text-[9px] font-bold text-rose-400 bg-rose-500/15 px-1 rounded truncate leading-tight">
                        -{dayData.expense >= 1000000 ? `${(dayData.expense / 1000000).toFixed(1)}M` : `${Math.round(dayData.expense / 1000)}k`}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Detail Transactions for Selected Date */}
      <div className="p-5 rounded-3xl bg-slate-900/80 border border-white/10 shadow-xl space-y-3">
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <i className="fa-solid fa-list-check text-cyan-400"></i>
              Riwayat Tanggal: {selectedDateStr}
            </h4>
            <p className="text-[11px] text-slate-400">
              {selectedDayData.items.length} catatan pada hari ini
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-emerald-400 font-bold">+{formatRupiah(selectedDayData.income)}</span>
            <span className="text-slate-600">|</span>
            <span className="text-rose-400 font-bold">-{formatRupiah(selectedDayData.expense)}</span>
          </div>
        </div>

        {selectedDayData.items.length === 0 ? (
          <div className="text-center py-6 text-xs text-slate-400">
            Tidak ada transaksi pada tanggal ini.
          </div>
        ) : (
          <div className="space-y-2">
            {selectedDayData.items.map(t => (
              <div
                key={t.id}
                className="p-3 rounded-2xl bg-slate-800/50 hover:bg-slate-800 border border-white/5 flex items-center justify-between gap-3 text-xs transition-all"
              >
                <div className="flex items-center space-x-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm ${
                      t.type === 'income'
                        ? 'bg-emerald-500/15 text-emerald-400'
                        : 'bg-rose-500/15 text-rose-400'
                    }`}
                  >
                    <i className={t.type === 'income' ? 'fa-solid fa-arrow-down-left' : 'fa-solid fa-arrow-up-right'}></i>
                  </div>
                  <div>
                    <p className="font-bold text-white">{t.title}</p>
                    <p className="text-[10px] text-slate-400">
                      {t.category} • {t.paymentMethod || 'Tunai'}
                      {t.notes && <span className="text-slate-500"> • {t.notes}</span>}
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <span
                    className={`font-black text-sm ${
                      t.type === 'income' ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {t.type === 'income' ? '+' : '-'}{formatRupiah(t.amount)}
                  </span>
                  {onDeleteTransaction && (
                    <button
                      onClick={() => onDeleteTransaction(t.id)}
                      className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-rose-500/10 transition-all"
                      title="Hapus Transaksi"
                    >
                      <i className="fa-solid fa-trash-can"></i>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
