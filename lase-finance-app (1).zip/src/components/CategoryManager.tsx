import React, { useState } from 'react';
import { CategoryItem, TransactionType } from '../types';

interface CategoryManagerProps {
  isOpen: boolean;
  onClose: () => void;
  categories: CategoryItem[];
  onAddCategory: (cat: Omit<CategoryItem, 'id' | 'userId'>) => void;
  onDeleteCategory: (id: string) => void;
}

const AVAILABLE_COLORS = [
  '#06b6d4', '#3b82f6', '#10b981', '#f59e0b',
  '#ef4444', '#ec4899', '#8b5cf6', '#14b8a6', '#64748b'
];

const AVAILABLE_ICONS = [
  { name: 'fa-utensils', label: 'Makanan' },
  { name: 'fa-basket-shopping', label: 'Belanja' },
  { name: 'fa-car-side', label: 'Transport' },
  { name: 'fa-receipt', label: 'Tagihan' },
  { name: 'fa-gamepad', label: 'Hiburan' },
  { name: 'fa-heart-pulse', label: 'Kesehatan' },
  { name: 'fa-graduation-cap', label: 'Pendidikan' },
  { name: 'fa-plane', label: 'Liburan' },
  { name: 'fa-money-bill-wave', label: 'Gaji' },
  { name: 'fa-laptop-code', label: 'Freelance' },
  { name: 'fa-chart-line', label: 'Investasi' },
  { name: 'fa-gift', label: 'Hadiah' },
  { name: 'fa-wallet', label: 'Umum' }
];

export const CategoryManager: React.FC<CategoryManagerProps> = ({
  isOpen,
  onClose,
  categories,
  onAddCategory,
  onDeleteCategory
}) => {
  const [activeTab, setActiveTab] = useState<TransactionType>('expense');
  const [newCatName, setNewCatName] = useState('');
  const [newCatColor, setNewCatColor] = useState('#06b6d4');
  const [newCatIcon, setNewCatIcon] = useState('fa-wallet');
  const [isAdding, setIsAdding] = useState(false);

  if (!isOpen) return null;

  const currentCategories = categories.filter(c => c.type === activeTab);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    onAddCategory({
      name: newCatName.trim(),
      type: activeTab,
      color: newCatColor,
      icon: newCatIcon
    });

    setNewCatName('');
    setIsAdding(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-lg bg-[#0f172a] border border-cyan-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden max-h-[92vh] overflow-y-auto">
        {/* Glow */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-all"
        >
          <i className="fa-solid fa-xmark text-lg"></i>
        </button>

        {/* Header */}
        <div className="mb-4">
          <div className="flex items-center gap-2 text-cyan-400 font-extrabold text-sm mb-1">
            <i className="fa-solid fa-tags text-base"></i>
            <span>Kelola Kategori Keuangan</span>
          </div>
          <p className="text-xs text-slate-400">
            Sesuaikan pos pengeluaran dan sumber pemasukan sesuai kebutuhan pribadi Anda.
          </p>
        </div>

        {/* Type Tabs */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-900 rounded-2xl mb-4 border border-white/5">
          <button
            type="button"
            onClick={() => {
              setActiveTab('expense');
              setIsAdding(false);
            }}
            className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'expense'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <i className="fa-solid fa-arrow-trend-down"></i>
            <span>Kategori Pengeluaran ({categories.filter(c => c.type === 'expense').length})</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('income');
              setIsAdding(false);
            }}
            className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'income'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <i className="fa-solid fa-arrow-trend-up"></i>
            <span>Kategori Pemasukan ({categories.filter(c => c.type === 'income').length})</span>
          </button>
        </div>

        {/* Add New Category Section */}
        {isAdding ? (
          <form onSubmit={handleCreate} className="p-4 mb-4 rounded-2xl bg-slate-900 border border-cyan-500/30 space-y-3 animate-fadeIn">
            <div className="flex justify-between items-center">
              <h4 className="text-xs font-bold text-white">Tambah Kategori {activeTab === 'expense' ? 'Pengeluaran' : 'Pemasukan'}</h4>
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                Batal
              </button>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Nama Kategori</label>
              <input
                type="text"
                required
                value={newCatName}
                onChange={(e) => setNewCatName(e.target.value)}
                placeholder="Misal: Kopi & Cafe, Kursus Online"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-cyan-400"
              />
            </div>

            {/* Color picker */}
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Pilih Warna</label>
              <div className="flex items-center gap-2 flex-wrap">
                {AVAILABLE_COLORS.map(c => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setNewCatColor(c)}
                    className={`w-6 h-6 rounded-full transition-transform ${newCatColor === c ? 'scale-125 ring-2 ring-white ring-offset-2 ring-offset-slate-900' : 'hover:scale-110'}`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>

            {/* Icon picker */}
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Pilih Ikon</label>
              <div className="grid grid-cols-6 gap-2 max-h-24 overflow-y-auto p-1 bg-slate-950 rounded-xl">
                {AVAILABLE_ICONS.map(ic => (
                  <button
                    key={ic.name}
                    type="button"
                    onClick={() => setNewCatIcon(ic.name)}
                    className={`p-2 rounded-lg text-center transition-all ${newCatIcon === ic.name ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
                    title={ic.label}
                  >
                    <i className={`fa-solid ${ic.name} text-xs`}></i>
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-98"
            >
              Simpan Kategori Baru
            </button>
          </form>
        ) : (
          <button
            type="button"
            onClick={() => setIsAdding(true)}
            className="w-full py-2.5 mb-4 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 rounded-2xl text-xs font-bold transition-all flex items-center justify-center gap-2 active:scale-98"
          >
            <i className="fa-solid fa-plus"></i>
            <span>Tambah Kategori Baru</span>
          </button>
        )}

        {/* Existing Categories List */}
        <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
          {currentCategories.map(cat => (
            <div
              key={cat.id}
              className="p-3 rounded-2xl bg-slate-900/60 hover:bg-slate-900 border border-white/5 flex items-center justify-between gap-3 text-xs"
            >
              <div className="flex items-center space-x-3">
                <div
                  className="w-8 h-8 rounded-xl flex items-center justify-center text-white font-bold"
                  style={{ backgroundColor: `${cat.color}25`, color: cat.color }}
                >
                  <i className={`fa-solid ${cat.icon} text-sm`}></i>
                </div>
                <div>
                  <p className="font-bold text-white">{cat.name}</p>
                  <p className="text-[10px] text-slate-400">
                    {cat.isDefault ? 'Kategori Bawaan' : 'Kustom Pengguna'}
                  </p>
                </div>
              </div>

              {!cat.isDefault && (
                <button
                  type="button"
                  onClick={() => onDeleteCategory(cat.id)}
                  className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-rose-500/10 transition-all"
                  title="Hapus Kategori Kustom"
                >
                  <i className="fa-solid fa-trash-can"></i>
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
