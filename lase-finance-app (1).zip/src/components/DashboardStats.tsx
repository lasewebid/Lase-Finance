import React, { useState, useMemo } from 'react';
import { Transaction } from '../types';
import { formatRupiah } from '../lib/exportUtils';

interface DashboardStatsProps {
  transactions: Transaction[];
  monthlyBudget: number;
}

export const DashboardStats: React.FC<DashboardStatsProps> = ({ transactions, monthlyBudget }) => {
  const [timeframe, setTimeframe] = useState<'today' | '7days' | 'month' | 'year' | 'all'>('month');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  // Filter transactions based on selected timeframe
  const filteredTransactions = useMemo(() => {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const currentMonthPrefix = now.toISOString().substring(0, 7);
    const currentYearPrefix = now.getFullYear().toString();

    return transactions.filter(t => {
      if (timeframe === 'today') return t.date === todayStr;
      if (timeframe === 'month') return t.date.startsWith(currentMonthPrefix);
      if (timeframe === 'year') return t.date.startsWith(currentYearPrefix);
      if (timeframe === '7days') {
        const txDate = new Date(t.date).getTime();
        const diffDays = (now.getTime() - txDate) / (1000 * 3600 * 24);
        return diffDays >= 0 && diffDays <= 7;
      }
      return true;
    });
  }, [transactions, timeframe]);

  // Aggregate numbers
  const totalIncome = useMemo(() => {
    return filteredTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
  }, [filteredTransactions]);

  const totalExpense = useMemo(() => {
    return filteredTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
  }, [filteredTransactions]);

  const netBalance = totalIncome - totalExpense;
  const savingsRate = totalIncome > 0 ? Math.max(0, Math.round(((totalIncome - totalExpense) / totalIncome) * 100)) : 0;
  const budgetPercentage = monthlyBudget > 0 ? Math.min(100, Math.round((totalExpense / monthlyBudget) * 100)) : 0;

  // Category breakdown for expenses
  const categoryExpenses = useMemo(() => {
    const map: { [cat: string]: number } = {};
    filteredTransactions
      .filter(t => t.type === 'expense')
      .forEach(t => {
        map[t.category] = (map[t.category] || 0) + t.amount;
      });

    const entries = Object.entries(map).map(([category, amount]) => ({
      category,
      amount,
      percentage: totalExpense > 0 ? Math.round((amount / totalExpense) * 100) : 0
    }));

    return entries.sort((a, b) => b.amount - a.amount);
  }, [filteredTransactions, totalExpense]);

  // Daily flow for the last 7 distinct dates
  const dailyFlow = useMemo(() => {
    const datesMap: { [date: string]: { income: number; expense: number } } = {};
    
    // Sort transactions by date asc
    const sorted = [...filteredTransactions].sort((a, b) => a.date.localeCompare(b.date));
    sorted.forEach(t => {
      if (!datesMap[t.date]) {
        datesMap[t.date] = { income: 0, expense: 0 };
      }
      if (t.type === 'income') datesMap[t.date].income += t.amount;
      else datesMap[t.date].expense += t.amount;
    });

    const entries = Object.entries(datesMap).map(([date, val]) => ({
      date: date.substring(5), // MM-DD
      fullDate: date,
      income: val.income,
      expense: val.expense,
      net: val.income - val.expense
    }));

    return entries.slice(-7);
  }, [filteredTransactions]);

  // Max value for daily flow chart scaling
  const maxFlowValue = useMemo(() => {
    const max = Math.max(
      ...dailyFlow.map(d => Math.max(d.income, d.expense)),
      100000
    );
    return max;
  }, [dailyFlow]);

  // Category colors palette
  const getCatColor = (index: number) => {
    const colors = ['#06b6d4', '#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#ef4444', '#14b8a6'];
    return colors[index % colors.length];
  };

  return (
    <div className="space-y-4">
      {/* Timeframe Selector */}
      <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1">
        <span className="text-xs font-semibold text-slate-400 whitespace-nowrap">Filter Periode:</span>
        <div className="flex items-center gap-1.5 bg-slate-900/90 p-1 rounded-2xl border border-white/10 text-xs">
          <button
            onClick={() => setTimeframe('today')}
            className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
              timeframe === 'today'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Hari Ini
          </button>
          <button
            onClick={() => setTimeframe('7days')}
            className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
              timeframe === '7days'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            7 Hari
          </button>
          <button
            onClick={() => setTimeframe('month')}
            className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
              timeframe === 'month'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Bulan Ini
          </button>
          <button
            onClick={() => setTimeframe('year')}
            className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
              timeframe === 'year'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Tahun Ini
          </button>
          <button
            onClick={() => setTimeframe('all')}
            className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
              timeframe === 'all'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Semua
          </button>
        </div>
      </div>

      {/* Primary KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Net Balance Card */}
        <div className="p-4 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900/90 to-cyan-950/40 border border-cyan-500/20 shadow-xl relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Saldo Bersih (Net)</p>
              <h3 className={`text-2xl font-black mt-1 ${netBalance >= 0 ? 'text-white' : 'text-red-400'}`}>
                {formatRupiah(netBalance)}
              </h3>
            </div>
            <div className={`p-2.5 rounded-2xl ${netBalance >= 0 ? 'bg-cyan-500/15 text-cyan-400' : 'bg-red-500/15 text-red-400'}`}>
              <i className={`fa-solid ${netBalance >= 0 ? 'fa-wallet' : 'fa-arrow-trend-down'} text-lg`}></i>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2 text-[11px] text-slate-400">
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${netBalance >= 0 ? 'bg-emerald-500/15 text-emerald-400' : 'bg-red-500/15 text-red-400'}`}>
              {netBalance >= 0 ? '+ Positif' : '- Defisit'}
            </span>
            <span>Rasio Tabungan: <strong className="text-white">{savingsRate}%</strong></span>
          </div>
        </div>

        {/* Total Income Card */}
        <div className="p-4 rounded-3xl bg-slate-900/80 border border-emerald-500/20 shadow-xl">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Pemasukan</p>
              <h3 className="text-2xl font-black text-emerald-400 mt-1">
                {formatRupiah(totalIncome)}
              </h3>
            </div>
            <div className="p-2.5 rounded-2xl bg-emerald-500/15 text-emerald-400">
              <i className="fa-solid fa-arrow-down-left text-lg"></i>
            </div>
          </div>
          <p className="mt-3 text-[11px] text-slate-400">
            {filteredTransactions.filter(t => t.type === 'income').length} transaksi masuk
          </p>
        </div>

        {/* Total Expense Card */}
        <div className="p-4 rounded-3xl bg-slate-900/80 border border-rose-500/20 shadow-xl">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Pengeluaran</p>
              <h3 className="text-2xl font-black text-rose-400 mt-1">
                {formatRupiah(totalExpense)}
              </h3>
            </div>
            <div className="p-2.5 rounded-2xl bg-rose-500/15 text-rose-400">
              <i className="fa-solid fa-arrow-up-right text-lg"></i>
            </div>
          </div>
          <p className="mt-3 text-[11px] text-slate-400">
            {filteredTransactions.filter(t => t.type === 'expense').length} transaksi keluar
          </p>
        </div>

        {/* Budget Usage Card */}
        <div className="p-4 rounded-3xl bg-slate-900/80 border border-indigo-500/20 shadow-xl">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Batas Anggaran Bulanan</p>
              <h3 className="text-lg font-bold text-white mt-1">
                {formatRupiah(monthlyBudget)}
              </h3>
            </div>
            <div className="p-2.5 rounded-2xl bg-indigo-500/15 text-indigo-400">
              <i className="fa-solid fa-bullseye text-lg"></i>
            </div>
          </div>
          <div className="mt-3 space-y-1.5">
            <div className="flex justify-between text-[11px]">
              <span className="text-slate-400">Terpakai:</span>
              <span className={`font-bold ${budgetPercentage > 85 ? 'text-rose-400' : 'text-cyan-400'}`}>
                {budgetPercentage}%
              </span>
            </div>
            <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-500 rounded-full ${
                  budgetPercentage > 85 ? 'bg-gradient-to-r from-amber-500 to-rose-500' : 'bg-gradient-to-r from-cyan-500 to-blue-500'
                }`}
                style={{ width: `${budgetPercentage}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Visual Dynamic Interactive Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Chart 1: Daily Cashflow Timeline (Bar chart) */}
        <div className="lg:col-span-2 p-5 rounded-3xl bg-slate-900/80 border border-white/10 shadow-xl space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <i className="fa-solid fa-chart-column text-cyan-400"></i>
                Arus Kas Harian (Pemasukan vs Pengeluaran)
              </h4>
              <p className="text-[11px] text-slate-400">Visualisasi dinamika transaksi harian</p>
            </div>
            <div className="flex items-center gap-3 text-[11px]">
              <span className="flex items-center gap-1.5 text-emerald-400">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Masuk
              </span>
              <span className="flex items-center gap-1.5 text-rose-400">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span> Keluar
              </span>
            </div>
          </div>

          {dailyFlow.length === 0 ? (
            <div className="h-44 flex items-center justify-center text-xs text-slate-500">
              Belum ada riwayat transaksi pada rentang periode ini.
            </div>
          ) : (
            <div className="h-48 flex items-end justify-between gap-2 pt-6 pb-2 px-2 border-b border-slate-800">
              {dailyFlow.map((day) => {
                const incomeHeight = Math.max(8, (day.income / maxFlowValue) * 100);
                const expenseHeight = Math.max(8, (day.expense / maxFlowValue) * 100);

                return (
                  <div key={day.fullDate} className="flex-1 flex flex-col items-center gap-1 group relative">
                    {/* Tooltip on hover */}
                    <div className="absolute -top-16 bg-slate-950 text-white border border-slate-700 px-2.5 py-1.5 rounded-xl text-[10px] shadow-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-30 whitespace-nowrap">
                      <p className="font-bold text-cyan-300">{day.fullDate}</p>
                      <p className="text-emerald-400">Masuk: {formatRupiah(day.income)}</p>
                      <p className="text-rose-400">Keluar: {formatRupiah(day.expense)}</p>
                      <p className="text-slate-300">Net: {formatRupiah(day.net)}</p>
                    </div>

                    <div className="w-full flex items-end justify-center gap-1 h-36">
                      {/* Income Bar */}
                      <div
                        className="w-1/2 max-w-[16px] bg-emerald-500 hover:bg-emerald-400 rounded-t-md transition-all shadow-md shadow-emerald-500/20"
                        style={{ height: `${day.income > 0 ? incomeHeight : 4}%` }}
                      />
                      {/* Expense Bar */}
                      <div
                        className="w-1/2 max-w-[16px] bg-rose-500 hover:bg-rose-400 rounded-t-md transition-all shadow-md shadow-rose-500/20"
                        style={{ height: `${day.expense > 0 ? expenseHeight : 4}%` }}
                      />
                    </div>
                    <span className="text-[10px] text-slate-400 group-hover:text-white transition-colors">
                      {day.date}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Chart 2: Category Breakdown Donut / List */}
        <div className="p-5 rounded-3xl bg-slate-900/80 border border-white/10 shadow-xl space-y-3">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <i className="fa-solid fa-chart-pie text-cyan-400"></i>
              Distribusi Kategori Pengeluaran
            </h4>
            <p className="text-[11px] text-slate-400">Persentase pengeluaran berdasarkan pos</p>
          </div>

          {categoryExpenses.length === 0 ? (
            <div className="h-44 flex items-center justify-center text-xs text-slate-500">
              Belum ada data pengeluaran.
            </div>
          ) : (
            <div className="space-y-3 pt-2">
              {/* Stacked Percentage Bar */}
              <div className="w-full h-3 bg-slate-800 rounded-full flex overflow-hidden">
                {categoryExpenses.map((cat, idx) => (
                  <div
                    key={cat.category}
                    className="h-full transition-all hover:opacity-80 cursor-pointer"
                    style={{
                      width: `${cat.percentage}%`,
                      backgroundColor: getCatColor(idx)
                    }}
                    title={`${cat.category}: ${cat.percentage}% (${formatRupiah(cat.amount)})`}
                    onClick={() => setActiveCategory(activeCategory === cat.category ? null : cat.category)}
                  />
                ))}
              </div>

              {/* Category Breakdown Items */}
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {categoryExpenses.map((cat, idx) => (
                  <div
                    key={cat.category}
                    onClick={() => setActiveCategory(activeCategory === cat.category ? null : cat.category)}
                    className={`flex items-center justify-between p-2 rounded-xl text-xs transition-all cursor-pointer ${
                      activeCategory === cat.category
                        ? 'bg-cyan-500/15 border border-cyan-500/40'
                        : 'bg-slate-800/40 hover:bg-slate-800/70'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: getCatColor(idx) }}
                      />
                      <span className="text-slate-200 font-medium truncate max-w-[120px]">
                        {cat.category}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-white font-bold block">{formatRupiah(cat.amount)}</span>
                      <span className="text-[10px] text-slate-400">{cat.percentage}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
