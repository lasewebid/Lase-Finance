import React, { useState, useMemo } from 'react';
import { Transaction, UserProfile } from '../types';
import { exportToExcel, exportToPDF, exportToCSV, formatRupiah, downloadAppZip } from '../lib/exportUtils';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
  userProfile?: UserProfile | null;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  transactions,
  userProfile
}) => {
  const [period, setPeriod] = useState<'month' | '3months' | 'year' | 'all'>('month');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [exporting, setExporting] = useState<boolean>(false);

  if (!isOpen) return null;

  // Filter transactions according to selected criteria
  const filteredList = useMemo(() => {
    const now = new Date();
    const currentMonthPrefix = now.toISOString().substring(0, 7);
    const currentYearPrefix = now.getFullYear().toString();

    return transactions.filter(t => {
      // Type filter
      if (filterType !== 'all' && t.type !== filterType) return false;

      // Period filter
      if (period === 'month') return t.date.startsWith(currentMonthPrefix);
      if (period === 'year') return t.date.startsWith(currentYearPrefix);
      if (period === '3months') {
        const txDate = new Date(t.date).getTime();
        const diffDays = (now.getTime() - txDate) / (1000 * 3600 * 24);
        return diffDays >= 0 && diffDays <= 90;
      }
      return true;
    });
  }, [transactions, period, filterType]);

  const totalIncome = filteredList.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const totalExpense = filteredList.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const netBalance = totalIncome - totalExpense;

  const handleExcelExport = () => {
    setExporting(true);
    setTimeout(() => {
      exportToExcel(filteredList, `Lase_Finance_${period}`);
      setExporting(false);
      onClose();
    }, 400);
  };

  const handleCSVExport = () => {
    setExporting(true);
    setTimeout(() => {
      exportToCSV(filteredList, `Lase_Finance_${period}`);
      setExporting(false);
      onClose();
    }, 400);
  };

  const handlePDFExport = () => {
    setExporting(true);
    setTimeout(() => {
      exportToPDF('pdf-export-content', `Laporan_Lase_${period}`);
      setExporting(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-xl bg-[#0f172a] border border-cyan-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden max-h-[92vh] overflow-y-auto">
        {/* Glow */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-all"
        >
          <i className="fa-solid fa-xmark text-lg"></i>
        </button>

        {/* Header */}
        <div className="mb-5">
          <div className="flex items-center gap-2 text-cyan-400 font-extrabold text-sm mb-1">
            <i className="fa-solid fa-file-arrow-down text-lg"></i>
            <span>Pusat Ekspor Laporan & Arsip Keuangan</span>
          </div>
          <p className="text-xs text-slate-400">
            Unduh rekapitulasi data keuangan dalam format Excel, PDF resmi, atau CSV.
          </p>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-2 gap-3 mb-5 p-3.5 bg-slate-900 rounded-2xl border border-white/5">
          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1">Rentang Periode</label>
            <select
              value={period}
              onChange={(e) => setPeriod(e.target.value as any)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2 px-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
            >
              <option value="month">Bulan Ini</option>
              <option value="3months">3 Bulan Terakhir</option>
              <option value="year">Tahun Berjalan (2026)</option>
              <option value="all">Semua Riwayat</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1">Tipe Transaksi</label>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as any)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2 px-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
            >
              <option value="all">Semua (Pemasukan & Pengeluaran)</option>
              <option value="expense">Hanya Pengeluaran</option>
              <option value="income">Hanya Pemasukan</option>
            </select>
          </div>
        </div>

        {/* Summary preview badge */}
        <div className="grid grid-cols-3 gap-2 mb-5 text-center">
          <div className="p-2.5 bg-slate-900 rounded-xl border border-white/5">
            <span className="text-[10px] text-slate-400 block">Jumlah Data</span>
            <span className="text-sm font-extrabold text-white">{filteredList.length} Item</span>
          </div>
          <div className="p-2.5 bg-slate-900 rounded-xl border border-emerald-500/20">
            <span className="text-[10px] text-slate-400 block">Pemasukan</span>
            <span className="text-xs font-bold text-emerald-400">{formatRupiah(totalIncome)}</span>
          </div>
          <div className="p-2.5 bg-slate-900 rounded-xl border border-rose-500/20">
            <span className="text-[10px] text-slate-400 block">Pengeluaran</span>
            <span className="text-xs font-bold text-rose-400">{formatRupiah(totalExpense)}</span>
          </div>
        </div>

        {/* Export Action Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
          {/* Excel Card */}
          <button
            onClick={handleExcelExport}
            disabled={exporting || filteredList.length === 0}
            className="p-3.5 rounded-2xl bg-emerald-950/40 hover:bg-emerald-900/40 border border-emerald-500/30 text-left transition-all active:scale-95 disabled:opacity-40 group flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-lg mb-2 group-hover:scale-110 transition-transform">
                <i className="fa-solid fa-file-excel"></i>
              </div>
              <h4 className="text-xs font-bold text-white">Format Excel (.xlsx)</h4>
              <p className="text-[10px] text-slate-400 mt-0.5">Tabel rapi + ringkasan total otomatis.</p>
            </div>
            <span className="mt-3 text-[11px] text-emerald-400 font-bold flex items-center gap-1">
              Unduh Excel <i className="fa-solid fa-arrow-down text-[9px]"></i>
            </span>
          </button>

          {/* PDF Card */}
          <button
            onClick={handlePDFExport}
            disabled={exporting || filteredList.length === 0}
            className="p-3.5 rounded-2xl bg-rose-950/40 hover:bg-rose-900/40 border border-rose-500/30 text-left transition-all active:scale-95 disabled:opacity-40 group flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center text-lg mb-2 group-hover:scale-110 transition-transform">
                <i className="fa-solid fa-file-pdf"></i>
              </div>
              <h4 className="text-xs font-bold text-white">Format PDF Resmi</h4>
              <p className="text-[10px] text-slate-400 mt-0.5">Dokumen laporan siap cetak & arsip.</p>
            </div>
            <span className="mt-3 text-[11px] text-rose-400 font-bold flex items-center gap-1">
              Unduh PDF <i className="fa-solid fa-arrow-down text-[9px]"></i>
            </span>
          </button>

          {/* CSV Card */}
          <button
            onClick={handleCSVExport}
            disabled={exporting || filteredList.length === 0}
            className="p-3.5 rounded-2xl bg-blue-950/40 hover:bg-blue-900/40 border border-blue-500/30 text-left transition-all active:scale-95 disabled:opacity-40 group flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center text-lg mb-2 group-hover:scale-110 transition-transform">
                <i className="fa-solid fa-file-csv"></i>
              </div>
              <h4 className="text-xs font-bold text-white">Format CSV (.csv)</h4>
              <p className="text-[10px] text-slate-400 mt-0.5">Kompatibel Google Sheets & software.</p>
            </div>
            <span className="mt-3 text-[11px] text-blue-400 font-bold flex items-center gap-1">
              Unduh CSV <i className="fa-solid fa-arrow-down text-[9px]"></i>
            </span>
          </button>
        </div>

        {/* Full Application Project Source ZIP */}
        <div className="p-4 bg-gradient-to-r from-cyan-950/40 via-slate-900 to-indigo-950/40 rounded-2xl border border-cyan-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-lg shrink-0">
              <i className="fa-solid fa-file-zipper"></i>
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Unduh Seluruh Aplikasi & Source Code (.ZIP)</h4>
              <p className="text-[10px] text-slate-400 mt-0.5">
                Paket lengkap berisi kode sumber, aset, konfigurasi PWA, dan berkas rilis Play Store.
              </p>
            </div>
          </div>
          <button
            onClick={() => downloadAppZip()}
            className="w-full sm:w-auto px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 whitespace-nowrap flex items-center justify-center gap-1.5"
          >
            <i className="fa-solid fa-download"></i>
            <span>Unduh File .ZIP</span>
          </button>
        </div>

        {/* Hidden Container for PDF rendering */}
        <div className="overflow-hidden h-0 w-0">
          <div id="pdf-export-content" className="p-8 bg-white text-slate-900 font-sans w-[800px]">
            {/* Header */}
            <div className="flex justify-between items-center border-b-2 border-slate-900 pb-4 mb-6">
              <div>
                <h1 className="text-2xl font-black tracking-tight text-slate-900">LASE FINANCE & PENGELUARAN</h1>
                <p className="text-xs text-slate-600">Laporan Transaksi Keuangan Resmi</p>
                <p className="text-xs text-slate-500 mt-1">Dicetak pada: {new Date().toLocaleString('id-ID')}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold text-slate-900">{userProfile?.name || 'Pengguna'}</p>
                <p className="text-xs text-slate-600">{userProfile?.email || '-'}</p>
                <p className="text-xs text-cyan-700 font-bold mt-1">Periode: {period.toUpperCase()}</p>
              </div>
            </div>

            {/* Financial Summary */}
            <div className="grid grid-cols-3 gap-4 mb-6 text-center">
              <div className="p-3 bg-slate-100 rounded-lg">
                <p className="text-xs text-slate-600">Total Pemasukan</p>
                <p className="text-base font-bold text-emerald-700">{formatRupiah(totalIncome)}</p>
              </div>
              <div className="p-3 bg-slate-100 rounded-lg">
                <p className="text-xs text-slate-600">Total Pengeluaran</p>
                <p className="text-base font-bold text-rose-700">{formatRupiah(totalExpense)}</p>
              </div>
              <div className="p-3 bg-slate-100 rounded-lg">
                <p className="text-xs text-slate-600">Saldo Bersih (Net)</p>
                <p className={`text-base font-bold ${netBalance >= 0 ? 'text-slate-900' : 'text-rose-700'}`}>
                  {formatRupiah(netBalance)}
                </p>
              </div>
            </div>

            {/* Table */}
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="border-b-2 border-slate-900 bg-slate-100">
                  <th className="py-2 px-2">No</th>
                  <th className="py-2 px-2">Tanggal</th>
                  <th className="py-2 px-2">Keterangan</th>
                  <th className="py-2 px-2">Kategori</th>
                  <th className="py-2 px-2">Metode</th>
                  <th className="py-2 px-2 text-right">Nominal</th>
                </tr>
              </thead>
              <tbody>
                {filteredList.map((t, idx) => (
                  <tr key={t.id} className="border-b border-slate-200">
                    <td className="py-2 px-2">{idx + 1}</td>
                    <td className="py-2 px-2 whitespace-nowrap">{t.date}</td>
                    <td className="py-2 px-2 font-medium">{t.title}</td>
                    <td className="py-2 px-2">{t.category}</td>
                    <td className="py-2 px-2">{t.paymentMethod || 'Tunai'}</td>
                    <td className={`py-2 px-2 text-right font-bold ${t.type === 'income' ? 'text-emerald-700' : 'text-rose-700'}`}>
                      {t.type === 'income' ? '+' : '-'}{formatRupiah(t.amount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="mt-8 text-center text-[10px] text-slate-500 border-t border-slate-200 pt-3">
              Dokumen ini dihasilkan secara otomatis oleh sistem Lase Finance & Pengeluaran.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
