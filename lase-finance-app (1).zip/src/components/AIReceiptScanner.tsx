import React, { useState, useRef } from 'react';
import { ReceiptScanResult } from '../types';
import { formatRupiah } from '../lib/exportUtils';

interface AIReceiptScannerProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyReceipt: (result: ReceiptScanResult) => void;
}

export const AIReceiptScanner: React.FC<AIReceiptScannerProps> = ({
  isOpen,
  onClose,
  onApplyReceipt
}) => {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('image/jpeg');
  const [loading, setLoading] = useState<boolean>(false);
  const [extractedData, setExtractedData] = useState<ReceiptScanResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setMimeType(file.type || 'image/jpeg');
    const reader = new FileReader();
    reader.onload = (evt) => {
      setImagePreview(evt.target?.result as string);
      setExtractedData(null);
      setErrorMsg('');
    };
    reader.readAsDataURL(file);
  };

  const handleScanWithAI = async () => {
    if (!imagePreview) {
      setErrorMsg('Pilih atau foto struk terlebih dahulu.');
      return;
    }

    setLoading(true);
    setErrorMsg('');

    try {
      const response = await fetch('/api/scan-receipt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: imagePreview,
          mimeType: mimeType
        })
      });

      const json = await response.json();
      if (!response.ok || !json.success) {
        throw new Error(json.error || 'Gagal memproses struk.');
      }

      setExtractedData(json.data);
    } catch (err: any) {
      console.error('Scan error:', err);
      setErrorMsg(err.message || 'Gagal membaca struk dengan AI Gemini.');
    } finally {
      setLoading(false);
    }
  };

  const handleApply = () => {
    if (extractedData) {
      onApplyReceipt(extractedData);
      onClose();
    }
  };

  const resetScanner = () => {
    setImagePreview(null);
    setExtractedData(null);
    setErrorMsg('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-lg bg-[#0f172a] border border-cyan-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden max-h-[92vh] overflow-y-auto">
        {/* Glow */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-all"
        >
          <i className="fa-solid fa-xmark text-lg"></i>
        </button>

        {/* Header */}
        <div className="mb-4">
          <div className="flex items-center gap-2 text-cyan-400 font-extrabold text-sm mb-1">
            <i className="fa-solid fa-wand-magic-sparkles text-base"></i>
            <span>Pemindai Struk AI Gemini Vision</span>
          </div>
          <p className="text-xs text-slate-400">
            Deteksi otomatis merchant, total nominal, pos kategori, dan rincian item belanja.
          </p>
        </div>

        {errorMsg && (
          <div className="p-3 mb-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs flex items-center gap-2">
            <i className="fa-solid fa-triangle-exclamation"></i>
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Image Preview Box */}
        <div className="space-y-3">
          <div className="w-full h-56 bg-slate-900 rounded-2xl border-2 border-dashed border-slate-700 overflow-hidden relative flex flex-col items-center justify-center">
            {imagePreview ? (
              <div className="w-full h-full relative">
                <img
                  src={imagePreview}
                  alt="Struk Preview"
                  className="w-full h-full object-contain p-2"
                />
                {loading && (
                  <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm flex flex-col items-center justify-center p-4">
                    {/* Laser scanning beam animation */}
                    <div className="w-48 h-1 bg-cyan-400 shadow-[0_0_15px_#22d3ee] animate-pulse rounded-full mb-3" />
                    <div className="inline-block animate-spin rounded-full h-8 w-8 border-3 border-cyan-400 border-t-transparent mb-2" />
                    <p className="text-xs font-bold text-cyan-300">Menganalisis teks & nominal struk...</p>
                    <p className="text-[10px] text-slate-400 mt-1">Ditenagai model Gemini Multimodal Vision</p>
                  </div>
                )}
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="text-center p-6 cursor-pointer hover:opacity-80 transition-opacity"
              >
                <div className="w-12 h-12 mx-auto rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-2 border border-cyan-500/20">
                  <i className="fa-solid fa-receipt text-xl"></i>
                </div>
                <p className="text-xs font-bold text-white">Ambil Foto atau Unggah Struk Belanja</p>
                <p className="text-[10px] text-slate-400 mt-0.5">Format JPG, PNG, WEBP (Mendukung Kamera HP)</p>
              </div>
            )}
          </div>

          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            capture="environment"
            onChange={handleFileChange}
            className="hidden"
          />

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 flex items-center justify-center gap-2 active:scale-95 transition-all"
            >
              <i className="fa-solid fa-camera"></i>
              <span>{imagePreview ? 'Ganti Foto' : 'Pilih / Foto'}</span>
            </button>

            <button
              type="button"
              disabled={!imagePreview || loading}
              onClick={handleScanWithAI}
              className="py-2.5 px-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-50"
            >
              <i className="fa-solid fa-bolt"></i>
              <span>Proses dengan AI</span>
            </button>
          </div>
        </div>

        {/* Extracted Result View */}
        {extractedData && (
          <div className="mt-5 p-4 rounded-2xl bg-slate-900 border border-cyan-500/40 space-y-3 animate-fadeIn">
            <div className="flex justify-between items-start border-b border-white/10 pb-2">
              <div>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold">
                  ✓ Berhasil Diekstrak
                </span>
                <h4 className="text-sm font-extrabold text-white mt-1">
                  {extractedData.merchant}
                </h4>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-400 block">Total Belanja:</span>
                <span className="text-base font-black text-cyan-300">
                  {formatRupiah(extractedData.amount)}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 bg-slate-800/60 rounded-xl">
                <span className="text-[10px] text-slate-400 block">Kategori Terdeteksi</span>
                <span className="font-semibold text-white">{extractedData.category}</span>
              </div>
              <div className="p-2 bg-slate-800/60 rounded-xl">
                <span className="text-[10px] text-slate-400 block">Metode Pembayaran</span>
                <span className="font-semibold text-white">{extractedData.paymentMethod}</span>
              </div>
            </div>

            {extractedData.items && extractedData.items.length > 0 && (
              <div className="space-y-1">
                <p className="text-[11px] font-bold text-slate-300">Rincian Barang:</p>
                <div className="max-h-28 overflow-y-auto space-y-1 pr-1 text-[11px]">
                  {extractedData.items.map((it, idx) => (
                    <div key={idx} className="flex justify-between text-slate-300 bg-slate-800/30 p-1.5 rounded-lg">
                      <span>{it.qty}x {it.name}</span>
                      <span className="font-mono text-cyan-400">{formatRupiah(it.price)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={handleApply}
              className="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 active:scale-98 transition-all"
            >
              <i className="fa-solid fa-check-double"></i>
              <span>Terapkan ke Catatan Keuangan</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
