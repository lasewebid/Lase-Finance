import React, { useState, useEffect } from 'react';
import { 
  testConnection, 
  auth, 
  subscribeTransactions, 
  addTransaction, 
  deleteTransaction, 
  getUserProfile, 
  saveUserProfile, 
  DEFAULT_CATEGORIES,
  getLocalTransactions
} from './lib/firebase';
import { getStoredJWT, clearJWT } from './lib/jwt';
import { initDailyReminder, sendPushNotification } from './lib/notifications';
import { formatRupiah, exportToExcel, exportToPDF, exportToCSV } from './lib/exportUtils';
import { UserProfile, Transaction, CategoryItem, JWTTokenData, ReceiptScanResult } from './types';

// Components
import { Navbar } from './components/Navbar';
import { AuthModal } from './components/AuthModal';
import { DashboardStats } from './components/DashboardStats';
import { InteractiveCalendar } from './components/InteractiveCalendar';
import { TransactionModal } from './components/TransactionModal';
import { AIReceiptScanner } from './components/AIReceiptScanner';
import { WhatsAppSender } from './components/WhatsAppSender';
import { ExportModal } from './components/ExportModal';
import { CategoryManager } from './components/CategoryManager';
import { ProfileModal } from './components/ProfileModal';
import { PlayStoreDeployModal } from './components/PlayStoreDeployModal';

export default function App() {
  // Global State
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const raw = localStorage.getItem('lase_active_user');
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  });

  const [jwtData, setJwtData] = useState<JWTTokenData | null>(getStoredJWT);
  const [transactions, setTransactions] = useState<Transaction[]>(getLocalTransactions);
  const [categories, setCategories] = useState<CategoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('lase_categories');
      if (saved) return JSON.parse(saved);
      return DEFAULT_CATEGORIES.map(c => ({ ...c, userId: 'default' }));
    } catch {
      return DEFAULT_CATEGORIES.map(c => ({ ...c, userId: 'default' }));
    }
  });

  const [isFirebaseConnected, setIsFirebaseConnected] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'calendar' | 'transactions' | 'reports'>('dashboard');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<'all' | 'income' | 'expense'>('all');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');

  // Modals state
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);
  const [isTxModalOpen, setIsTxModalOpen] = useState<boolean>(false);
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);
  const [isWhatsAppOpen, setIsWhatsAppOpen] = useState<boolean>(false);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);
  const [isCategoryOpen, setIsCategoryOpen] = useState<boolean>(false);
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [isPlayStoreModalOpen, setIsPlayStoreModalOpen] = useState<boolean>(false);

  // Selected item for WhatsApp share or edit
  const [selectedTxForWA, setSelectedTxForWA] = useState<Transaction | null>(null);
  const [txInitialData, setTxInitialData] = useState<Partial<Transaction> | undefined>(undefined);

  // PWA Install Prompt State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  // 1. Initial Connection & PWA Listener
  useEffect(() => {
    testConnection().then(ok => setIsFirebaseConnected(ok));

    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstall);

    // Initial default demo user if not logged in
    if (!user) {
      const defaultUser: UserProfile = {
        userId: 'usr_demo_vip_2026',
        name: 'Elysia Lase',
        email: 'elisialase762@gmail.com',
        monthlyBudget: 6000000,
        currency: 'IDR',
        enableDailyReminder: true,
        reminderTime: '20:00',
        waNumber: '081234567890'
      };
      setUser(defaultUser);
      localStorage.setItem('lase_active_user', JSON.stringify(defaultUser));
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  // 2. Real-time Firestore Transactions Listener
  useEffect(() => {
    if (!user) return;

    // Initialize daily reminder
    initDailyReminder(user.enableDailyReminder, user.reminderTime, user.name);

    // Real-time Firestore listener
    const unsubscribe = subscribeTransactions(user.userId, (updatedList) => {
      setTransactions(updatedList);
    });

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [user]);

  // Seed initial sample data if empty
  useEffect(() => {
    if (transactions.length === 0 && user) {
      const today = new Date().toISOString().split('T')[0];
      const sampleTxs: Transaction[] = [
        {
          id: 'tx_seed_1',
          userId: user.userId,
          title: 'Gaji Pokok & Tunjangan',
          amount: 8500000,
          type: 'income',
          category: 'Gaji Pokok',
          date: today,
          paymentMethod: 'Transfer Bank',
          notes: 'Gaji bulan ini',
          createdAt: new Date().toISOString()
        },
        {
          id: 'tx_seed_2',
          userId: user.userId,
          title: 'Belanja Mingguan Supermarket',
          amount: 450000,
          type: 'expense',
          category: 'Belanja Harian',
          date: today,
          paymentMethod: 'QRIS',
          notes: 'Kebutuhan pokok dan buah',
          createdAt: new Date().toISOString()
        },
        {
          id: 'tx_seed_3',
          userId: user.userId,
          title: 'Makan Siang & Kopi Artisan',
          amount: 85000,
          type: 'expense',
          category: 'Makanan & Minuman',
          date: today,
          paymentMethod: 'QRIS',
          notes: 'Makan siang bersama tim',
          createdAt: new Date().toISOString()
        }
      ];
      setTransactions(sampleTxs);
      localStorage.setItem('lase_transactions', JSON.stringify(sampleTxs));
    }
  }, [user]);

  // PWA Install handler
  const handlePwaInstall = () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then((choice: any) => {
        if (choice.outcome === 'accepted') {
          setDeferredPrompt(null);
        }
      });
    } else {
      alert("Aplikasi ini siap digunakan di Android! Tekan menu browser lalu pilih 'Tambahkan ke Layar Utama'.");
    }
  };

  // Auth Handlers
  const handleLoginSuccess = (profile: UserProfile, jwt: JWTTokenData) => {
    setUser(profile);
    setJwtData(jwt);
    localStorage.setItem('lase_active_user', JSON.stringify(profile));
    saveUserProfile(profile);
    sendPushNotification('Selamat Datang di Lase Finance! 🚀', {
      body: `Halo ${profile.name}, sesi Anda telah aman terenkripsi dengan JWT.`
    });
  };

  const handleLogout = () => {
    clearJWT();
    setJwtData(null);
    localStorage.removeItem('lase_active_user');
    setUser(null);
    setIsAuthOpen(true);
  };

  // Transaction Save
  const handleSaveTransaction = async (txData: Omit<Transaction, 'id' | 'userId'>, sendWhatsApp: boolean) => {
    if (!user) return;
    const newTx = await addTransaction(user.userId, txData);
    
    // Push Notification
    sendPushNotification('Transaksi Berhasil Dicatat 💳', {
      body: `${newTx.title}: ${newTx.type === 'income' ? '+' : '-'}${formatRupiah(newTx.amount)}`
    });

    if (sendWhatsApp) {
      setSelectedTxForWA(newTx);
      setIsWhatsAppOpen(true);
    }
  };

  // Delete Transaction
  const handleDeleteTransaction = async (id: string) => {
    if (!user) return;
    if (confirm('Apakah Anda yakin ingin menghapus catatan transaksi ini?')) {
      await deleteTransaction(user.userId, id);
    }
  };

  // Apply Receipt from AI
  const handleApplyReceipt = (receipt: ReceiptScanResult) => {
    setTxInitialData({
      title: receipt.merchant || 'Belanja Nota AI',
      amount: receipt.amount || 0,
      type: 'expense',
      category: receipt.category || 'Belanja Harian',
      date: receipt.date || new Date().toISOString().split('T')[0],
      paymentMethod: receipt.paymentMethod || 'QRIS',
      notes: receipt.notes || ''
    });
    setIsTxModalOpen(true);
  };

  // Add custom category
  const handleAddCategory = (cat: Omit<CategoryItem, 'id' | 'userId'>) => {
    const newCat: CategoryItem = {
      ...cat,
      id: `cat_${Date.now()}`,
      userId: user?.userId || 'default'
    };
    const updated = [...categories, newCat];
    setCategories(updated);
    localStorage.setItem('lase_categories', JSON.stringify(updated));
  };

  // Delete custom category
  const handleDeleteCategory = (id: string) => {
    const updated = categories.filter(c => c.id !== id);
    setCategories(updated);
    localStorage.setItem('lase_categories', JSON.stringify(updated));
  };

  // Profile Save
  const handleSaveProfile = (updated: UserProfile) => {
    setUser(updated);
    localStorage.setItem('lase_active_user', JSON.stringify(updated));
    saveUserProfile(updated);
  };

  // Export JSON Backup
  const handleExportBackup = () => {
    const backup = {
      user,
      transactions,
      categories,
      exportedAt: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lase_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  // Import JSON Backup
  const handleImportBackup = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        if (data.transactions && Array.isArray(data.transactions)) {
          setTransactions(data.transactions);
          localStorage.setItem('lase_transactions', JSON.stringify(data.transactions));
        }
        if (data.user) {
          setUser(data.user);
          localStorage.setItem('lase_active_user', JSON.stringify(data.user));
        }
        if (data.categories && Array.isArray(data.categories)) {
          setCategories(data.categories);
          localStorage.setItem('lase_categories', JSON.stringify(data.categories));
        }
        alert('Data berhasil dipulihkan (Restore) dengan sukses!');
      } catch (err) {
        alert('Gagal membaca format file backup JSON.');
      }
    };
    reader.readAsText(file);
  };

  // Filtered Transactions for List View
  const filteredTransactions = transactions.filter(t => {
    const matchSearch = t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (t.notes && t.notes.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchType = selectedTypeFilter === 'all' || t.type === selectedTypeFilter;
    const matchCat = selectedCategoryFilter === 'all' || t.category === selectedCategoryFilter;

    return matchSearch && matchType && matchCat;
  });

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col justify-between selection:bg-cyan-500 selection:text-white pb-24 md:pb-12">
      {/* Top Navbar */}
      <Navbar
        user={user}
        jwtData={jwtData}
        isFirebaseConnected={isFirebaseConnected}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenNotifications={() => setIsProfileOpen(true)}
        onLogout={handleLogout}
        onInstallPwa={handlePwaInstall}
        canInstallPwa={!!deferredPrompt}
        onOpenPlayStore={() => setIsPlayStoreModalOpen(true)}
      />

      {/* Main Container */}
      <main className="max-w-6xl mx-auto w-full px-4 pt-4 pb-8 flex-1 space-y-6">
        {/* Navigation Tabs Bar */}
        <div className="flex items-center justify-between gap-2 overflow-x-auto p-1.5 bg-slate-900/90 rounded-2xl border border-white/10 shadow-lg">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
                activeTab === 'dashboard'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <i className="fa-solid fa-chart-line text-xs"></i>
              <span>Dashboard & Grafik</span>
            </button>

            <button
              onClick={() => setActiveTab('calendar')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
                activeTab === 'calendar'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <i className="fa-solid fa-calendar-days text-xs"></i>
              <span>Kalender Keuangan</span>
            </button>

            <button
              onClick={() => setActiveTab('transactions')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
                activeTab === 'transactions'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <i className="fa-solid fa-wallet text-xs"></i>
              <span>Daftar Transaksi ({transactions.length})</span>
            </button>

            <button
              onClick={() => setIsCategoryOpen(true)}
              className="px-3 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-cyan-400 hover:bg-slate-800/60 transition-all flex items-center gap-1.5 whitespace-nowrap"
            >
              <i className="fa-solid fa-tags text-xs"></i>
              <span>Kategori</span>
            </button>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                setSelectedTxForWA(null);
                setIsWhatsAppOpen(true);
              }}
              className="p-2 sm:px-3 sm:py-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold text-xs flex items-center gap-1.5 transition-all active:scale-95 whitespace-nowrap"
              title="Kirim Rekap WhatsApp"
            >
              <i className="fa-brands fa-whatsapp text-sm"></i>
              <span className="hidden sm:inline">Rekap WA</span>
            </button>

            <button
              onClick={() => setIsExportOpen(true)}
              className="p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs flex items-center gap-1.5 transition-all active:scale-95 whitespace-nowrap"
              title="Ekspor PDF/Excel"
            >
              <i className="fa-solid fa-file-arrow-down text-sm text-cyan-400"></i>
              <span className="hidden sm:inline">Ekspor Data</span>
            </button>

            <button
              onClick={() => setIsScannerOpen(true)}
              className="p-2 sm:px-3.5 sm:py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-md shadow-cyan-500/20 flex items-center gap-1.5 transition-all active:scale-95 whitespace-nowrap"
              title="Scan Struk AI"
            >
              <i className="fa-solid fa-camera text-sm"></i>
              <span className="hidden sm:inline">Scan Struk AI</span>
            </button>

            <button
              onClick={() => {
                setTxInitialData(undefined);
                setIsTxModalOpen(true);
              }}
              className="px-3 sm:px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs shadow-md shadow-cyan-500/30 flex items-center gap-1.5 transition-all active:scale-95 whitespace-nowrap"
            >
              <i className="fa-solid fa-plus text-xs"></i>
              <span>Tambah</span>
            </button>
          </div>
        </div>

        {/* TAB CONTENT 1: DASHBOARD */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6 animate-fadeIn">
            <DashboardStats
              transactions={transactions}
              monthlyBudget={user?.monthlyBudget || 5000000}
            />

            {/* Quick Scanner & WhatsApp Action Banners */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* AI Scanner Banner */}
              <div className="p-5 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-cyan-950/40 border border-cyan-500/30 shadow-xl flex items-center justify-between gap-4">
                <div className="flex items-center space-x-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 text-xl shadow-lg shadow-cyan-500/20">
                    <i className="fa-solid fa-wand-magic-sparkles"></i>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Pemindai Struk AI Gemini</h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Foto struk belanja, AI mengekstrak nominal, toko & kategori otomatis.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsScannerOpen(true)}
                  className="px-4 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 whitespace-nowrap"
                >
                  Pindai Struk
                </button>
              </div>

              {/* WhatsApp Recap Banner */}
              <div className="p-5 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 border border-emerald-500/30 shadow-xl flex items-center justify-between gap-4">
                <div className="flex items-center space-x-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 text-xl shadow-lg shadow-emerald-500/20">
                    <i className="fa-brands fa-whatsapp"></i>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Kirim Rekap ke WhatsApp</h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Otomatis kirim ringkasan arus kas harian ke nomor HP Anda.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setSelectedTxForWA(null);
                    setIsWhatsAppOpen(true);
                  }}
                  className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 whitespace-nowrap"
                >
                  Kirim WA
                </button>
              </div>
            </div>

            {/* Recent 5 Transactions with Fast View */}
            <div className="p-5 rounded-3xl bg-slate-900/80 border border-white/10 shadow-xl space-y-3">
              <div className="flex justify-between items-center border-b border-white/10 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <i className="fa-solid fa-clock-rotate-left text-cyan-400"></i>
                    Transaksi Terakhir
                  </h3>
                  <p className="text-[11px] text-slate-400">5 aktivitas keuangan teranyar</p>
                </div>
                <button
                  onClick={() => setActiveTab('transactions')}
                  className="text-xs text-cyan-400 hover:underline font-semibold"
                >
                  Lihat Semua ({transactions.length})
                </button>
              </div>

              {transactions.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-500">
                  Belum ada transaksi. Klik "Tambah" untuk mencatat pemasukan atau pengeluaran pertama Anda.
                </div>
              ) : (
                <div className="space-y-2">
                  {transactions.slice(0, 5).map(t => (
                    <div
                      key={t.id}
                      className="p-3 rounded-2xl bg-slate-800/50 hover:bg-slate-800/90 border border-white/5 flex items-center justify-between gap-3 text-xs transition-all"
                    >
                      <div className="flex items-center space-x-3">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm ${
                            t.type === 'income'
                              ? 'bg-emerald-500/15 text-emerald-400'
                              : 'bg-rose-500/15 text-rose-400'
                          }`}
                        >
                          <i className={t.type === 'income' ? 'fa-solid fa-arrow-down-left' : 'fa-solid fa-arrow-up-right'}></i>
                        </div>
                        <div>
                          <p className="font-bold text-white">{t.title}</p>
                          <p className="text-[10px] text-slate-400">
                            {t.date} • <span className="text-cyan-300">{t.category}</span> • {t.paymentMethod || 'Tunai'}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <span className={`font-black text-sm ${t.type === 'income' ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {t.type === 'income' ? '+' : '-'}{formatRupiah(t.amount)}
                        </span>
                        <button
                          onClick={() => {
                            setSelectedTxForWA(t);
                            setIsWhatsAppOpen(true);
                          }}
                          className="p-1.5 text-slate-400 hover:text-emerald-400 rounded-lg hover:bg-slate-700/60 transition-all"
                          title="Kirim ke WhatsApp"
                        >
                          <i className="fa-brands fa-whatsapp text-sm"></i>
                        </button>
                        <button
                          onClick={() => handleDeleteTransaction(t.id)}
                          className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-rose-500/10 transition-all"
                          title="Hapus"
                        >
                          <i className="fa-solid fa-trash-can"></i>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB CONTENT 2: CALENDAR */}
        {activeTab === 'calendar' && (
          <div className="animate-fadeIn">
            <InteractiveCalendar
              transactions={transactions}
              onDeleteTransaction={handleDeleteTransaction}
            />
          </div>
        )}

        {/* TAB CONTENT 3: TRANSACTIONS LIST */}
        {activeTab === 'transactions' && (
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-white/10 shadow-xl space-y-4 animate-fadeIn">
            {/* Filter Bar */}
            <div className="flex flex-col md:flex-row gap-3 justify-between items-center">
              {/* Search */}
              <div className="relative w-full md:w-72">
                <i className="fa-solid fa-magnifying-glass absolute left-3.5 top-3 text-slate-400 text-xs"></i>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cari transaksi, toko, atau catatan..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                />
              </div>

              {/* Type and Category dropdowns */}
              <div className="flex items-center gap-2 w-full md:w-auto">
                <select
                  value={selectedTypeFilter}
                  onChange={(e) => setSelectedTypeFilter(e.target.value as any)}
                  className="bg-slate-800 border border-slate-700 rounded-xl py-2 px-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                >
                  <option value="all">Semua Tipe</option>
                  <option value="expense">Pengeluaran Saja</option>
                  <option value="income">Pemasukan Saja</option>
                </select>

                <select
                  value={selectedCategoryFilter}
                  onChange={(e) => setSelectedCategoryFilter(e.target.value)}
                  className="bg-slate-800 border border-slate-700 rounded-xl py-2 px-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                >
                  <option value="all">Semua Kategori</option>
                  {categories.map(c => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                </select>

                <button
                  onClick={() => setIsExportOpen(true)}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
                >
                  <i className="fa-solid fa-file-export"></i>
                  <span>Ekspor</span>
                </button>
              </div>
            </div>

            {/* Transaction List */}
            {filteredTransactions.length === 0 ? (
              <div className="text-center py-12 text-xs text-slate-400">
                Tidak ada transaksi yang cocok dengan filter pencarian.
              </div>
            ) : (
              <div className="space-y-2">
                {filteredTransactions.map(t => (
                  <div
                    key={t.id}
                    className="p-3.5 rounded-2xl bg-slate-800/40 hover:bg-slate-800/80 border border-white/5 flex items-center justify-between gap-3 text-xs transition-all"
                  >
                    <div className="flex items-center space-x-3.5">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-base ${
                          t.type === 'income'
                            ? 'bg-emerald-500/15 text-emerald-400'
                            : 'bg-rose-500/15 text-rose-400'
                        }`}
                      >
                        <i className={t.type === 'income' ? 'fa-solid fa-arrow-down-left' : 'fa-solid fa-arrow-up-right'}></i>
                      </div>
                      <div>
                        <p className="font-bold text-white text-sm">{t.title}</p>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          {t.date} • <span className="text-cyan-300 font-medium">{t.category}</span> • <span className="text-slate-300">{t.paymentMethod || 'Tunai'}</span>
                          {t.notes && <span className="text-slate-500"> • {t.notes}</span>}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      <span className={`font-black text-sm md:text-base ${t.type === 'income' ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {t.type === 'income' ? '+' : '-'}{formatRupiah(t.amount)}
                      </span>
                      <button
                        onClick={() => {
                          setSelectedTxForWA(t);
                          setIsWhatsAppOpen(true);
                        }}
                        className="p-2 text-slate-400 hover:text-emerald-400 rounded-xl hover:bg-emerald-500/10 transition-all"
                        title="Kirim ke WhatsApp"
                      >
                        <i className="fa-brands fa-whatsapp text-base"></i>
                      </button>
                      <button
                        onClick={() => handleDeleteTransaction(t.id)}
                        className="p-2 text-slate-500 hover:text-rose-400 rounded-xl hover:bg-rose-500/10 transition-all"
                        title="Hapus"
                      >
                        <i className="fa-solid fa-trash-can text-sm"></i>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Floating Bottom Navigation Bar (Mobile Optimized) */}
      <nav className="md:hidden fixed bottom-3 left-3 right-3 z-40 bg-[#090d16]/90 backdrop-blur-xl border border-white/10 rounded-3xl p-2 flex justify-around items-center shadow-2xl">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center p-2 rounded-2xl transition-all ${
            activeTab === 'dashboard' ? 'text-cyan-400 font-bold' : 'text-slate-400'
          }`}
        >
          <i className="fa-solid fa-chart-line text-lg"></i>
          <span className="text-[10px] mt-1">Dashboard</span>
        </button>

        <button
          onClick={() => setActiveTab('calendar')}
          className={`flex flex-col items-center p-2 rounded-2xl transition-all ${
            activeTab === 'calendar' ? 'text-cyan-400 font-bold' : 'text-slate-400'
          }`}
        >
          <i className="fa-solid fa-calendar-days text-lg"></i>
          <span className="text-[10px] mt-1">Kalender</span>
        </button>

        {/* Center Scanner Action */}
        <button
          onClick={() => setIsScannerOpen(true)}
          className="w-12 h-12 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 text-white flex items-center justify-center shadow-lg shadow-cyan-500/40 -mt-6 active:scale-90 transition-all"
          title="Scan Struk AI"
        >
          <i className="fa-solid fa-camera text-xl"></i>
        </button>

        <button
          onClick={() => setActiveTab('transactions')}
          className={`flex flex-col items-center p-2 rounded-2xl transition-all ${
            activeTab === 'transactions' ? 'text-cyan-400 font-bold' : 'text-slate-400'
          }`}
        >
          <i className="fa-solid fa-wallet text-lg"></i>
          <span className="text-[10px] mt-1">Transaksi</span>
        </button>

        <button
          onClick={() => setIsProfileOpen(true)}
          className="flex flex-col items-center p-2 rounded-2xl text-slate-400 hover:text-cyan-400 transition-all"
        >
          <i className="fa-solid fa-gear text-lg"></i>
          <span className="text-[10px] mt-1">Setelan</span>
        </button>
      </nav>

      {/* ALL MODALS */}
      {/* 1. Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      {/* 2. Transaction Modal */}
      <TransactionModal
        isOpen={isTxModalOpen}
        onClose={() => {
          setIsTxModalOpen(false);
          setTxInitialData(undefined);
        }}
        onSave={handleSaveTransaction}
        categories={categories}
        userProfile={user}
        initialData={txInitialData}
      />

      {/* 3. AI Receipt Scanner Modal */}
      <AIReceiptScanner
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onApplyReceipt={handleApplyReceipt}
      />

      {/* 4. WhatsApp Sharing & Template Modal */}
      <WhatsAppSender
        isOpen={isWhatsAppOpen}
        onClose={() => setIsWhatsAppOpen(false)}
        userProfile={user}
        transaction={selectedTxForWA}
        dailyTransactions={transactions}
        onSaveTemplate={(template, phone) => {
          if (user) {
            handleSaveProfile({
              ...user,
              waTemplate: template,
              waNumber: phone
            });
          }
        }}
      />

      {/* 5. Export Modal (PDF / Excel / CSV) */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        transactions={transactions}
        userProfile={user}
      />

      {/* 6. Category Manager Modal */}
      <CategoryManager
        isOpen={isCategoryOpen}
        onClose={() => setIsCategoryOpen(false)}
        categories={categories}
        onAddCategory={handleAddCategory}
        onDeleteCategory={handleDeleteCategory}
      />

      {/* 7. Profile & Settings Modal */}
      {user && (
        <ProfileModal
          isOpen={isProfileOpen}
          onClose={() => setIsProfileOpen(false)}
          user={user}
          onSaveProfile={handleSaveProfile}
          onExportBackup={handleExportBackup}
          onImportBackup={handleImportBackup}
        />
      )}

      {/* 8. Google Play Store Deployment Modal */}
      <PlayStoreDeployModal
        isOpen={isPlayStoreModalOpen}
        onClose={() => setIsPlayStoreModalOpen(false)}
        appUrl={typeof window !== 'undefined' ? window.location.origin : 'https://ais-pre-g2z7byl4kqk37umqsgte7t-794837337461.asia-east1.run.app'}
      />
    </div>
  );
}
