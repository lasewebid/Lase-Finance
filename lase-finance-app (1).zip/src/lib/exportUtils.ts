import * as XLSX from 'xlsx';
import { Transaction } from '../types';

export function formatRupiah(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount).replace('Rp', 'Rp ');
}

// Export to Microsoft Excel (.xlsx)
export function exportToExcel(transactions: Transaction[], title: string = 'Laporan_Keuangan_Lase') {
  if (transactions.length === 0) {
    alert('Tidak ada transaksi untuk diekspor.');
    return;
  }

  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpense = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const netBalance = totalIncome - totalExpense;

  const rows = transactions.map((t, idx) => ({
    'No': idx + 1,
    'Tanggal': t.date,
    'Keterangan': t.title,
    'Tipe': t.type === 'income' ? 'Pemasukan' : 'Pengeluaran',
    'Kategori': t.category,
    'Metode Pembayaran': t.paymentMethod || 'Tunai',
    'Nominal (Rp)': t.amount,
    'Catatan': t.notes || '-'
  }));

  const ws = XLSX.utils.json_to_sheet(rows);

  const summaryRows = [
    {},
    { 'Keterangan': 'RINGKASAN KEUANGAN' },
    { 'Keterangan': 'Total Pemasukan:', 'Nominal (Rp)': totalIncome },
    { 'Keterangan': 'Total Pengeluaran:', 'Nominal (Rp)': totalExpense },
    { 'Keterangan': 'Saldo Bersih (Net):', 'Nominal (Rp)': netBalance }
  ];

  XLSX.utils.sheet_add_json(ws, summaryRows, { origin: -1, skipHeader: true });

  ws['!cols'] = [
    { wch: 6 },
    { wch: 14 },
    { wch: 28 },
    { wch: 14 },
    { wch: 20 },
    { wch: 18 },
    { wch: 16 },
    { wch: 30 }
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Transaksi');

  const fileName = `${title}_${new Date().toISOString().split('T')[0]}.xlsx`;
  XLSX.writeFile(wb, fileName);
}

// Export to CSV (.csv)
export function exportToCSV(transactions: Transaction[], title: string = 'Laporan_Keuangan_Lase') {
  if (transactions.length === 0) {
    alert('Tidak ada data transaksi untuk diekspor.');
    return;
  }

  const headers = ['No', 'Tanggal', 'Keterangan', 'Tipe', 'Kategori', 'Metode Pembayaran', 'Nominal', 'Catatan'];
  const rows = transactions.map((t, i) => [
    i + 1,
    `"${t.date}"`,
    `"${t.title.replace(/"/g, '""')}"`,
    `"${t.type === 'income' ? 'Pemasukan' : 'Pengeluaran'}"`,
    `"${t.category}"`,
    `"${t.paymentMethod || 'Tunai'}"`,
    t.amount,
    `"${(t.notes || '').replace(/"/g, '""')}"`
  ]);

  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${title}_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Export to PDF using html2pdf
export function exportToPDF(elementId: string, filename: string = 'Laporan_Keuangan_Lase') {
  const element = document.getElementById(elementId);
  if (!element) {
    console.error('Target element for PDF not found:', elementId);
    return;
  }

  // @ts-ignore
  if (typeof window.html2pdf !== 'undefined') {
    const opt = {
      margin: [10, 10, 10, 10],
      filename: `${filename}_${new Date().toISOString().split('T')[0]}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true, logging: false },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };
    // @ts-ignore
    window.html2pdf().set(opt).from(element).save();
  } else {
    window.print();
  }
}

// Download application project ZIP using Blob for maximum iframe compatibility
export async function downloadAppZip(): Promise<boolean> {
  try {
    const res = await fetch('/api/download-zip');
    if (!res.ok) {
      throw new Error(`HTTP error ${res.status}`);
    }
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'lase-finance-app.zip';
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    }, 1000);
    return true;
  } catch (err) {
    console.warn('Blob download fallback to direct window location:', err);
    window.open('/api/download-zip', '_blank');
    return false;
  }
}
