import { initializeApp, getApps } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged,
  User as FirebaseUser 
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDocFromServer, 
  collection, 
  setDoc, 
  getDocs, 
  deleteDoc, 
  onSnapshot,
  query,
  orderBy,
  updateDoc
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { Transaction, CategoryItem, UserProfile } from '../types';

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

// CRITICAL: Must pass firestoreDatabaseId
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// Test connection constraint from skill
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("Firebase client is currently offline. Local cache in effect.");
    }
    return false;
  }
}

// Error Handler mandated by Firebase integration skill
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Default initial categories
export const DEFAULT_CATEGORIES: Omit<CategoryItem, 'userId'>[] = [
  { id: 'cat-food', name: 'Makanan & Minuman', type: 'expense', icon: 'fa-utensils', color: '#f59e0b', isDefault: true },
  { id: 'cat-groceries', name: 'Belanja Harian', type: 'expense', icon: 'fa-basket-shopping', color: '#10b981', isDefault: true },
  { id: 'cat-transport', name: 'Transportasi', type: 'expense', icon: 'fa-car-side', color: '#3b82f6', isDefault: true },
  { id: 'cat-bills', name: 'Tagihan & Utilitas', type: 'expense', icon: 'fa-receipt', color: '#ef4444', isDefault: true },
  { id: 'cat-entertainment', name: 'Hiburan & Liburan', type: 'expense', icon: 'fa-gamepad', color: '#8b5cf6', isDefault: true },
  { id: 'cat-health', name: 'Kesehatan', type: 'expense', icon: 'fa-heart-pulse', color: '#ec4899', isDefault: true },
  { id: 'cat-salary', name: 'Gaji Pokok', type: 'income', icon: 'fa-money-bill-wave', color: '#10b981', isDefault: true },
  { id: 'cat-freelance', name: 'Proyek / Freelance', type: 'income', icon: 'fa-laptop-code', color: '#06b6d4', isDefault: true },
  { id: 'cat-investment', name: 'Investasi & Dividen', type: 'income', icon: 'fa-chart-line', color: '#6366f1', isDefault: true },
  { id: 'cat-other-inc', name: 'Pemasukan Lainnya', type: 'income', icon: 'fa-coins', color: '#14b8a6', isDefault: true },
  { id: 'cat-other-exp', name: 'Lain-lain', type: 'expense', icon: 'fa-wallet', color: '#64748b', isDefault: true }
];

// User Profile Operations
export async function getUserProfile(userId: string): Promise<UserProfile | null> {
  const path = `users/${userId}`;
  try {
    const snap = await getDocFromServer(doc(db, 'users', userId));
    if (snap.exists()) {
      return snap.data() as UserProfile;
    }
    return null;
  } catch (error) {
    // If offline or permission check, try local or return fallback
    try {
      const local = localStorage.getItem(`lase_profile_${userId}`);
      if (local) return JSON.parse(local);
    } catch {}
    return null;
  }
}

export async function saveUserProfile(profile: UserProfile): Promise<void> {
  const path = `users/${profile.userId}`;
  try {
    await setDoc(doc(db, 'users', profile.userId), {
      ...profile,
      updatedAt: new Date().toISOString()
    });
    localStorage.setItem(`lase_profile_${profile.userId}`, JSON.stringify(profile));
  } catch (error) {
    localStorage.setItem(`lase_profile_${profile.userId}`, JSON.stringify(profile));
    console.warn('Saved profile locally because Firestore write failed:', error);
  }
}

// Transaction Operations
export async function addTransaction(userId: string, tx: Omit<Transaction, 'id' | 'userId'>): Promise<Transaction> {
  const id = `tx_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const newTx: Transaction = {
    ...tx,
    id,
    userId,
    createdAt: new Date().toISOString()
  };

  const path = `users/${userId}/transactions/${id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'transactions', id), newTx);
  } catch (error) {
    console.warn('Falling back to local storage for transaction write:', error);
  }

  // Also cache locally
  saveLocalTransaction(newTx);
  return newTx;
}

export async function deleteTransaction(userId: string, transactionId: string): Promise<void> {
  const path = `users/${userId}/transactions/${transactionId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'transactions', transactionId));
  } catch (error) {
    console.warn('Firebase delete error, removing locally:', error);
  }
  removeLocalTransaction(transactionId);
}

// Helper to keep local storage mirror
export function getLocalTransactions(): Transaction[] {
  try {
    const raw = localStorage.getItem('lase_transactions');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveLocalTransaction(tx: Transaction): void {
  const list = getLocalTransactions().filter(t => t.id !== tx.id);
  list.unshift(tx);
  localStorage.setItem('lase_transactions', JSON.stringify(list));
}

export function removeLocalTransaction(id: string): void {
  const list = getLocalTransactions().filter(t => t.id !== id);
  localStorage.setItem('lase_transactions', JSON.stringify(list));
}

// Subscribe to real-time transactions
export function subscribeTransactions(userId: string, onUpdate: (txs: Transaction[]) => void) {
  const q = query(collection(db, 'users', userId, 'transactions'), orderBy('date', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const list: Transaction[] = [];
    snapshot.forEach((doc) => {
      list.push(doc.data() as Transaction);
    });
    // Update local cache
    localStorage.setItem('lase_transactions', JSON.stringify(list));
    onUpdate(list);
  }, (err) => {
    console.warn('Transaction listener error, using local data:', err);
    onUpdate(getLocalTransactions());
  });
}
