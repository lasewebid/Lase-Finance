import { JWTTokenData } from '../types';

// Base64URL utilities
export function base64UrlEncode(str: string): string {
  return btoa(str)
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

export function base64UrlDecode(str: string): string {
  let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
  while (base64.length % 4) {
    base64 += '=';
  }
  return atob(base64);
}

// Generate an authentic HS256-signed JWT token using browser Web Crypto API
export async function generateJWT(user: { id: string; email: string; name: string }): Promise<JWTTokenData> {
  const header = {
    alg: 'HS256',
    typ: 'JWT'
  };

  const now = Math.floor(Date.now() / 1000);
  const exp = now + 7 * 24 * 60 * 60; // 7 days validity

  const payload = {
    sub: user.id,
    email: user.email,
    name: user.name,
    role: 'verified_user',
    iat: now,
    exp: exp,
    iss: 'https://lase-finance.web.id'
  };

  const encodedHeader = base64UrlEncode(JSON.stringify(header));
  const encodedPayload = base64UrlEncode(JSON.stringify(payload));
  const unsignedToken = `${encodedHeader}.${encodedPayload}`;

  // Use a secret key derivation with Web Crypto
  const secretKey = 'lase_finance_jwt_secure_app_secret_key_2026';
  const encoder = new TextEncoder();
  const keyData = encoder.encode(secretKey);

  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const signatureBuffer = await crypto.subtle.sign(
    'HMAC',
    cryptoKey,
    encoder.encode(unsignedToken)
  );

  const signatureArray = Array.from(new Uint8Array(signatureBuffer));
  const signatureString = String.fromCharCode.apply(null, signatureArray);
  const encodedSignature = base64UrlEncode(signatureString);

  const fullToken = `${unsignedToken}.${encodedSignature}`;

  const tokenData: JWTTokenData = {
    token: fullToken,
    expiresAt: exp * 1000,
    payload
  };

  localStorage.setItem('lase_jwt_session', JSON.stringify(tokenData));
  return tokenData;
}

export function getStoredJWT(): JWTTokenData | null {
  try {
    const raw = localStorage.getItem('lase_jwt_session');
    if (!raw) return null;
    const data: JWTTokenData = JSON.parse(raw);
    if (Date.now() > data.expiresAt) {
      localStorage.removeItem('lase_jwt_session');
      return null;
    }
    return data;
  } catch {
    return null;
  }
}

export function clearJWT(): void {
  localStorage.removeItem('lase_jwt_session');
}

export function parseJWT(token: string): any {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const payload = JSON.parse(base64UrlDecode(parts[1]));
    return payload;
  } catch {
    return null;
  }
}
