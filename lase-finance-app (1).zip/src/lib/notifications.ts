export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (!('Notification' in window)) {
    console.warn('Browser ini tidak mendukung notifikasi push.');
    return 'denied';
  }

  const permission = await Notification.requestPermission();
  return permission;
}

export function sendPushNotification(title: string, options?: NotificationOptions) {
  if (!('Notification' in window)) return;

  if (Notification.permission === 'granted') {
    const defaultOptions = {
      icon: 'https://placehold.co/192x192/06b6d4/ffffff?text=Lase',
      badge: 'https://placehold.co/96x96/06b6d4/ffffff?text=L',
      ...options
    };
    new Notification(title, defaultOptions as NotificationOptions);
  }
}

// Background checker for daily reminder
let reminderInterval: any = null;

export function initDailyReminder(enabled: boolean, reminderTime: string, userName: string = 'Pengguna') {
  if (reminderInterval) {
    clearInterval(reminderInterval);
    reminderInterval = null;
  }

  if (!enabled || !reminderTime) return;

  // Check every minute if current time matches reminder time
  reminderInterval = setInterval(() => {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const currentTime = `${hours}:${minutes}`;

    const todayStr = now.toISOString().split('T')[0];
    const lastNotifiedDay = localStorage.getItem('lase_last_reminder_day');

    if (currentTime === reminderTime && lastNotifiedDay !== todayStr) {
      localStorage.setItem('lase_last_reminder_day', todayStr);
      sendPushNotification('Pengingat Keuangan Harian 🔔', {
        body: `Halo ${userName}, sudahkah Anda mencatat transaksi belanja dan pemasukan hari ini? Mari jaga finansial tetap rapi!`,
        tag: 'daily-reminder'
      });
    }
  }, 30000); // Check every 30 seconds
}
